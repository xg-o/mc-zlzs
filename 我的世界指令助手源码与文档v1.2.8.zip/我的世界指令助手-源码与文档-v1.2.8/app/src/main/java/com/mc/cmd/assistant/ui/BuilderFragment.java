package com.mc.cmd.assistant.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.ai.AiActivity;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Models.Arg;
import com.mc.cmd.assistant.data.Models.Template;
import com.mc.cmd.assistant.data.Prefs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BuilderFragment extends Fragment {

    private Template tpl;
    private final Map<String, View> fieldViews = new HashMap<>();
    private TextView out, syntax;
    private final List<Chip> chips = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_builder, container, false);
        out = v.findViewById(R.id.builderOut);
        syntax = v.findViewById(R.id.tplSyntax);
        buildChips(v);

        v.findViewById(R.id.builderCopy).setOnClickListener(x -> {
            String c = out.getText().toString();
            if (!c.isEmpty()) { Clip.copy(requireContext(), c); new Prefs(requireContext()).pushLastCmd(c); }
        });
        v.findViewById(R.id.builderFav).setOnClickListener(x -> {
            String c = out.getText().toString();
            if (!c.isEmpty()) {
                boolean on = new Prefs(requireContext()).toggleFav("custom", "builder|" + c, "拼接 · " + c, c, "命令拼接");
                toast(on ? getString(R.string.fav_added) : getString(R.string.fav_removed));
            }
        });
        v.findViewById(R.id.builderAi).setOnClickListener(x -> {
            String c = out.getText().toString();
            Intent i = new Intent(getContext(), AiActivity.class);
            i.putExtra("prompt", c.isEmpty() ? "" : getString(R.string.ai_optimize_prompt, c));
            startActivity(i);
        });
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        View v = getView();
        if (v != null) buildChips(v);
    }

    private void buildChips(View v) {
        chips.clear();
        ChipGroup cg = v.findViewById(R.id.tplChips);
        cg.removeAllViews();
        DataStore ds = DataStore.get();
        java.util.List<Template> tpls = new java.util.ArrayList<>();
        if (new Prefs(requireContext()).getBuiltinEnabled()) tpls.addAll(ds.templates);
        tpls.addAll(new Prefs(requireContext()).sourceTemplates());
        for (Template t : tpls) {
            Chip chip = new Chip(requireContext());
            chip.setText(t.n);
            chip.setTag(t);
            chip.setCheckable(true);
            chip.setOnClickListener(x -> select((Template) chip.getTag()));
            cg.addView(chip);
            chips.add(chip);
        }
        select(tpls.isEmpty() ? null : tpls.get(0));
    }

    private void toast(String s) { android.widget.Toast.makeText(requireContext(), s, android.widget.Toast.LENGTH_SHORT).show(); }

    private void select(Template t) {
        tpl = t;
        for (Chip c : chips) c.setChecked(t != null && c.getTag() == t);
        if (t == null) return;
        syntax.setText(t.s);
        LinearLayout fields = getView() == null ? null : getView().findViewById(R.id.fields);
        if (fields == null) return;
        fields.removeAllViews();
        fieldViews.clear();
        LayoutInflater li = LayoutInflater.from(requireContext());

        for (Arg a : t.args) {
            if ("fix".equals(a.t)) {
                TextInputLayout til = new TextInputLayout(requireContext());
                til.setLabelFor(View.NO_ID);
                TextView tv = new TextView(requireContext());
                tv.setText("固定段  " + a.d);
                tv.setTextSize(13f);
                tv.setTypeface(android.graphics.Typeface.MONOSPACE);
                tv.setTextColor(0xFF6750A4);
                tv.setPadding(4, 10, 4, 4);
                fields.addView(tv);
                continue;
            }
            TextInputLayout til = new TextInputLayout(requireContext());
            til.setHint(a.l + (a.opt ? "（可选）" : ""));
            til.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);
            til.setPadding(0, 8, 0, 4);

            AutoCompleteTextView tv = new AutoCompleteTextView(requireContext());
            tv.setId(View.generateViewId());
            tv.setTextSize(15f);
            tv.setInputType(InputType.TYPE_CLASS_TEXT);
            if (a.h != null && !a.h.isEmpty()) tv.setHint(a.h);
            if (a.d != null && !a.d.isEmpty() && !"true".equals(a.d)) tv.setText(a.d);
            String[] sugg = suggFor(a);
            if (sugg.length > 0) {
                ArrayAdapter<String> ad = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, sugg);
                tv.setAdapter(ad);
            }
            tv.setOnClickListener(x -> { if (tv.getAdapter() != null) tv.showDropDown(); });
            tv.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
                @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
                @Override public void afterTextChanged(android.text.Editable s) { refreshOut(); }
            });
            til.addView(tv);
            fields.addView(til);
            fieldViews.put(a.k, tv);
        }
        refreshOut();
    }

    private String[] suggFor(Arg a) {
        List<String> list = new ArrayList<>();
        if (!a.o.isEmpty()) list.addAll(a.o);
        else if (!a.sug.isEmpty()) list.addAll(a.sug);
        else if (a.sugPool != null) list.addAll(DataStore.get().sugPool(a.sugPool));
        else if ("id".equals(a.t)) list.addAll(DataStore.get().sugPool("id"));
        else if ("select".equals(a.t)) list.addAll(a.o);
        return list.toArray(new String[0]);
    }

    private void refreshOut() {
        if (tpl == null) return;
        Map<String, String> vals = new HashMap<>();
        for (Map.Entry<String, View> e : fieldViews.entrySet()) {
            AutoCompleteTextView tv = (AutoCompleteTextView) e.getValue();
            vals.put(e.getKey(), tv.getText() == null ? "" : tv.getText().toString());
        }
        out.setText(DataStore.get().buildCommand(tpl.id, vals));
    }
}
