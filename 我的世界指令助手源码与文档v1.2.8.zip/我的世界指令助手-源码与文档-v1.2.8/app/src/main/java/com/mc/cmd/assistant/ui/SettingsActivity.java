package com.mc.cmd.assistant.ui;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.ai.AiClient;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Models.Provider;
import com.mc.cmd.assistant.data.Prefs;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import com.mc.cmd.assistant.BaseActivity;

public class SettingsActivity extends BaseActivity {

    private AutoCompleteTextView provider, model;
    private TextInputEditText key, base, headers, temp, prompt;
    private android.widget.TextView providerNote;
    private Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        prefs = new Prefs(this);
        provider = findViewById(R.id.stProvider);
        model = findViewById(R.id.stModel);
        key = findViewById(R.id.stKey);
        base = findViewById(R.id.stBase);
        headers = findViewById(R.id.stHeaders);
        temp = findViewById(R.id.stTemp);
        prompt = findViewById(R.id.stPrompt);
        providerNote = findViewById(R.id.stProviderNote);

        findViewById(R.id.toolbar).setOnClickListener(x -> finish());

        List<String> pNames = new ArrayList<>();
        List<Provider> ps = DataStore.get().providers;
        for (Provider p : ps) pNames.add(p.name);
        provider.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, pNames));
        provider.setThreshold(1);
        provider.setOnClickListener(v -> provider.showDropDown());
        provider.setOnFocusChangeListener((v, has) -> { if (has) provider.showDropDown(); });

        JSONObject st = prefs.getSettings();
        String curProvider = st.optString("provider", "deepseek");
        String curModel = st.optString("model", "");
        provider.setText(providerName(curProvider), false);
        key.setText(st.optString("apiKey"));
        base.setText(st.optString("baseURL"));
        headers.setText(st.optString("extraHeaders"));
        temp.setText(String.valueOf(st.optDouble("temperature", 0.7)));
        prompt.setText(st.optString("systemPrompt", DataStore.get().defaultPrompt));
        refreshModels(curProvider, curModel, st.optString("baseURL"));

        model.setThreshold(1);
        model.setOnClickListener(v -> model.showDropDown());
        model.setOnFocusChangeListener((v, has) -> { if (has) model.showDropDown(); });

        provider.setOnItemClickListener((a, v, pos, id) -> {
            Provider p = ps.get(pos);
            refreshModels(p.id, p.models.isEmpty() ? "" : p.models.get(0), "");
            refreshNote(p);
        });
        refreshNote(currentProvider(ps));
        model.setOnItemClickListener((a, v, pos, id) -> {
        });

        findViewById(R.id.stSave).setOnClickListener(x -> save());
        findViewById(R.id.stTest).setOnClickListener(x -> {
            if (!save(false)) return;
            JSONObject s = prefs.getSettings();
            new Thread(() -> {
                String r = AiClient.test(s);
                runOnUiThread(() -> Toast.makeText(this, r, Toast.LENGTH_LONG).show());
            }).start();
        });
    }

    private String providerName(String id) {
        for (Provider p : DataStore.get().providers) if (p.id.equals(id)) return p.name;
        return "DeepSeek";
    }

    private Provider currentProvider(List<Provider> ps) {
        String id = new Prefs(this).getSettings().optString("provider", "deepseek");
        for (Provider p : ps) if (p.id.equals(id)) return p;
        return ps.isEmpty() ? null : ps.get(0);
    }

    private void refreshNote(Provider p) {
        if (p == null || providerNote == null) return;
        String note = p.note;
        if (note == null || note.isEmpty()) {
            note = getString(R.string.st_provider_custom) + " · " + getString(R.string.st_support_note);
        }
        providerNote.setText(note);
    }

    private void refreshModels(String providerId, String selModel, String baseUrl) {
        List<String> ms = new ArrayList<>();
        Provider cur = null;
        for (Provider p : DataStore.get().providers) if (p.id.equals(providerId)) cur = p;
        if (cur != null) ms.addAll(cur.models);
        if (!ms.contains(selModel)) ms.add(0, selModel);
        model.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ms));
        model.setText(selModel, false);
        if (cur != null && baseUrl.isEmpty()) base.setText(cur.base);
    }

    private boolean save() {
        return save(true);
    }

    private boolean save(boolean toast) {
        String pName = provider.getText() == null ? "" : provider.getText().toString().trim();
        String providerId = "custom";
        for (Provider p : DataStore.get().providers) if (p.name.equals(pName)) providerId = p.id;
        try {
            JSONObject st = new JSONObject();
            st.put("provider", providerId);
            st.put("model", text(model));
            st.put("apiKey", text(key));
            st.put("baseURL", text(base));
            st.put("extraHeaders", text(headers));
            st.put("temperature", text(temp).isEmpty() ? 0.7 : Double.parseDouble(text(temp)));
            st.put("systemPrompt", text(prompt));
            prefs.saveSettings(st);
            if (toast) Toast.makeText(this, R.string.st_saved, Toast.LENGTH_SHORT).show();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.st_save_fail, e.getMessage()), Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private String text(android.widget.EditText t) {
        return t.getText() == null ? "" : t.getText().toString().trim();
    }
}
