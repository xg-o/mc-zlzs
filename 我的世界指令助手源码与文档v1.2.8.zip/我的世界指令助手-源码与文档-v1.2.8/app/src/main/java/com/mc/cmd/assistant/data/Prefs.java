package com.mc.cmd.assistant.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 本地存储：收藏 / 命令本 / AI 设置 / 最近命令（供悬浮窗） */
public class Prefs {
    private static final String NAME = "mc_assistant_prefs";
    public static final String KEY_FAVS = "favs";
    public static final String KEY_AI_SAVED = "ai_saved";
    public static final String KEY_SETTINGS = "settings";
    public static final String KEY_LAST_CMDS = "last_cmds";
    public static final String KEY_HIST = "ai_hist";

    private final SharedPreferences sp;

    public Prefs(Context c) { sp = c.getSharedPreferences(NAME, Context.MODE_PRIVATE); }

    public String get(String key) { return sp.getString(key, ""); }
    public void set(String key, String val) { sp.edit().putString(key, val).commit(); }

    // ---- 外观：主题与语言 ----
    public static final String KEY_THEME = "theme";
    public static final String KEY_THEME_CUSTOM = "theme_custom";
    public static final String KEY_LANG = "lang";
    public String getTheme() { return sp.getString(KEY_THEME, "purple"); }
    public void setTheme(String id) { sp.edit().putString(KEY_THEME, id).commit(); }
    public String getThemeCustom() { return sp.getString(KEY_THEME_CUSTOM, ""); }
    public void setThemeCustom(String hex) { sp.edit().putString(KEY_THEME_CUSTOM, hex).commit(); }
    public String getLang() { return sp.getString(KEY_LANG, ""); }
    public void setLang(String lang) { sp.edit().putString(KEY_LANG, lang).commit(); }

    // ---- 本地 API 服务端口 ----
    public static final String KEY_API_PORT = "api_port";
    public int getApiPort() { return sp.getInt(KEY_API_PORT, 8756); }
    public void setApiPort(int p) { sp.edit().putInt(KEY_API_PORT, p).commit(); }


    // ---- 当前会话 ----
    public static final String KEY_CURRENT_CONV = "current_conv";
    public String getCurrentConv() { return sp.getString(KEY_CURRENT_CONV, ""); }
    public void setCurrentConv(String id) { sp.edit().putString(KEY_CURRENT_CONV, id).commit(); }

    // ---- AI 会话：JSON 数组 [{id,title,cat,ts,msgs:[{role,content}]}] ----
    public static final String KEY_CONVS = "conversations";
    public JSONArray getConvs() {
        try { return new JSONArray(get(KEY_CONVS)); } catch (Exception e) { return new JSONArray(); }
    }
    public void saveConvs(JSONArray a) { set(KEY_CONVS, a.toString()); }
    public void pushConv(JSONObject o) {
        try {
            JSONArray a = getConvs();
            JSONArray na = new JSONArray();
            na.put(o);
            for (int i = 0; i < a.length(); i++) na.put(a.opt(i));
            set(KEY_CONVS, na.toString());
        } catch (Exception ignored) {}
    }

    // ---- 收藏：JSON 数组 [{type,ref,label,cmd,sub,ts}] ----
    public JSONArray getFavs() {
        try { return new JSONArray(get(KEY_FAVS)); } catch (Exception e) { return new JSONArray(); }
    }
    public boolean isFav(String type, String ref) {
        JSONArray a = getFavs();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && type.equals(o.optString("type")) && ref.equals(o.optString("ref"))) return true;
        }
        return false;
    }
    public boolean toggleFav(String type, String ref, String label, String cmd, String sub) {
        JSONArray a = getFavs();
        int idx = -1;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && type.equals(o.optString("type")) && ref.equals(o.optString("ref"))) { idx = i; break; }
        }
        if (idx >= 0) {
            JSONArray na = new JSONArray();
            for (int i = 0; i < a.length(); i++) if (i != idx) na.put(a.opt(i));
            set(KEY_FAVS, na.toString());
            return false;
        }
        try {
            JSONObject o = new JSONObject();
            o.put("type", type); o.put("ref", ref); o.put("label", label == null ? "" : label);
            o.put("cmd", cmd == null ? "" : cmd); o.put("sub", sub == null ? "" : sub); o.put("ts", System.currentTimeMillis());
            JSONArray na = new JSONArray();
            na.put(o);
            for (int i = 0; i < a.length(); i++) na.put(a.opt(i));
            set(KEY_FAVS, na.toString());
        } catch (Exception ignored) {}
        return true;
    }
    public void removeFav(String type, String ref) {
        JSONArray a = getFavs();
        JSONArray na = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !(type.equals(o.optString("type")) && ref.equals(o.optString("ref")))) na.put(a.opt(i));
        }
        set(KEY_FAVS, na.toString());
    }

    // ---- 命令本：JSON 数组 [{cmd, ts}] ----
    public JSONArray getAiSaved() {
        try { return new JSONArray(get(KEY_AI_SAVED)); } catch (Exception e) { return new JSONArray(); }
    }
    public void saveCmd(String cmd) {
        try {
            JSONArray a = getAiSaved();
            JSONObject o = new JSONObject();
            o.put("cmd", cmd); o.put("ts", System.currentTimeMillis());
            JSONArray na = new JSONArray();
            na.put(o);
            for (int i = 0; i < a.length(); i++) na.put(a.opt(i));
            set(KEY_AI_SAVED, na.toString());
        } catch (Exception ignored) {}
    }
    public void saveCmds(List<String> cmds) {
        if (cmds == null) return;
        for (String c : cmds) if (c != null && !c.trim().isEmpty()) saveCmd(c.trim());
    }
    public void clearAiSaved() { set(KEY_AI_SAVED, "[]"); }
    public void removeAiSaved(long ts, String cmd) {
        JSONArray a = getAiSaved();
        JSONArray na = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || o.optLong("ts") != ts || !cmd.equals(o.optString("cmd"))) na.put(a.opt(i));
        }
        set(KEY_AI_SAVED, na.toString());
    }

    // ---- 最近命令（悬浮窗快捷） ----
    public List<String> getLastCmds() {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(get(KEY_LAST_CMDS));
            for (int i = 0; i < a.length(); i++) out.add(a.optString(i));
        } catch (Exception ignored) {}
        return out;
    }
    public void pushLastCmd(String cmd) {
        if (cmd == null || cmd.trim().isEmpty()) return;
        List<String> l = new ArrayList<>();
        l.add(cmd.trim());
        for (String s : getLastCmds()) if (!s.equals(cmd.trim())) l.add(s);
        while (l.size() > 20) l.remove(l.size() - 1);
        JSONArray a = new JSONArray(l);
        set(KEY_LAST_CMDS, a.toString());
    }

    public void removeLastCmd(String cmd) {
        if (cmd == null) return;
        List<String> l = new ArrayList<>();
        for (String s : getLastCmds()) if (!s.equals(cmd.trim())) l.add(s);
        JSONArray a = new JSONArray(l);
        set(KEY_LAST_CMDS, a.toString());
    }

    // ---- AI 设置 ----
    public JSONObject getSettings() {
        try { return new JSONObject(get(KEY_SETTINGS)); } catch (Exception e) { return new JSONObject(); }
    }
    public String s(JSONObject o, String k, String def) { return o.has(k) ? o.optString(k) : def; }
    public void saveSettings(JSONObject o) { set(KEY_SETTINGS, o.toString()); }

    // ---- AI 对话历史 ----
    public JSONArray getHist() {
        try { return new JSONArray(get(KEY_HIST)); } catch (Exception e) { return new JSONArray(); }
    }
    public void pushHist(String role, String content) {
        try {
            JSONArray a = getHist();
            JSONObject o = new JSONObject();
            o.put("role", role); o.put("content", content); o.put("ts", System.currentTimeMillis());
            JSONArray na = new JSONArray();
            na.put(o);
            for (int i = 0; i < a.length(); i++) na.put(a.opt(i));
            set(KEY_HIST, na.toString());
        } catch (Exception ignored) {}
    }
    public void popHist() {
        JSONArray a = getHist();
        JSONArray na = new JSONArray();
        for (int i = 0; i < a.length(); i++) if (i != 0) na.put(a.opt(i));
        set(KEY_HIST, na.toString());
    }
    public void clearHist() { set(KEY_HIST, "[]"); }

    // ---- 首次启动 / 我的世界信息 ----
    public static final String KEY_ONBOARDED = "onboarded";
    public boolean isOnboarded() { return sp.getBoolean(KEY_ONBOARDED, false); }
    public void setOnboarded() { sp.edit().putBoolean(KEY_ONBOARDED, true).commit(); }

    public static final String KEY_MC_PLATFORM = "mc_platform"; // bedrock / java
    public static final String KEY_MC_DEVICE = "mc_device";     // mobile / pc
    public static final String KEY_MC_VERSION = "mc_version";   // 如 1.26.45.1
    public String getMcPlatform() { return sp.getString(KEY_MC_PLATFORM, ""); }
    public String getMcDevice() { return sp.getString(KEY_MC_DEVICE, ""); }
    public String getMcVersion() { return sp.getString(KEY_MC_VERSION, ""); }
    public void setMcInfo(String platform, String device, String version) {
        sp.edit().putString(KEY_MC_PLATFORM, platform == null ? "" : platform)
                .putString(KEY_MC_DEVICE, device == null ? "" : device)
                .putString(KEY_MC_VERSION, version == null ? "" : version)
                .commit();
    }


    // ---- 内置命令库开关 ----
    public static final String KEY_BUILTIN_ENABLED = "builtin_enabled";
    public static final String KEY_BUILTIN_DELETED = "builtin_deleted";
    public boolean getBuiltinDeleted() { return sp.getBoolean(KEY_BUILTIN_DELETED, false); }
    public void setBuiltinDeleted(boolean del) { sp.edit().putBoolean(KEY_BUILTIN_DELETED, del).commit(); }
    public void restoreBuiltin() {
        sp.edit().putBoolean(KEY_BUILTIN_DELETED, false).putBoolean(KEY_BUILTIN_ENABLED, true).commit();
    }
    public boolean getBuiltinEnabled() {
        return sp.getBoolean(KEY_BUILTIN_ENABLED, true) && !sp.getBoolean(KEY_BUILTIN_DELETED, false);
    }
    public void setBuiltinEnabled(boolean on) { sp.edit().putBoolean(KEY_BUILTIN_ENABLED, on).commit(); }

    // ---- 命令源：JSON 数组 [{id,name,url,enabled,ts,cmds:[{cmd,d}]}] ----
    public static final String KEY_SOURCES = "sources";
    public JSONArray getSources() {
        try { return new JSONArray(get(KEY_SOURCES)); } catch (Exception e) { return new JSONArray(); }
    }
    public void saveSources(JSONArray a) { set(KEY_SOURCES, a.toString()); }

    /** 已开启预设命令源合并为预设列表（分类=命令源，仅 type=preset） */
    public List<Models.Preset> sourcePresets() {
        List<Models.Preset> out = new ArrayList<>();
        JSONArray a = getSources();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !o.optBoolean("enabled", true)) continue;
            String type = o.optString("type", "preset");
            if (!"preset".equals(type)) continue;
            String name = o.optString("name");
            JSONArray cmds = o.optJSONArray("cmds");
            if (cmds == null) continue;
            for (int j = 0; j < cmds.length(); j++) {
                JSONObject c = cmds.optJSONObject(j);
                if (c == null) continue;
                String cmd = c.optString("cmd");
                if (cmd.isEmpty()) cmd = c.optString("command");
                if (cmd.isEmpty()) cmd = c.optString("c");
                if (cmd.isEmpty()) continue;
                String d = c.optString("d");
                if (d.isEmpty()) d = c.optString("desc");
                String desc = "来源：" + name + (d.isEmpty() ? "" : " · " + d);
                out.add(new Models.Preset("命令源", cmd, desc));
            }
        }
        return out;
    }

    /** 已开启拼接模板源（type=template） */
    public List<Models.Template> sourceTemplates() {
        List<Models.Template> out = new ArrayList<>();
        JSONArray a = getSources();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !o.optBoolean("enabled", true)) continue;
            if (!"template".equals(o.optString("type", "preset"))) continue;
            JSONArray cmds = o.optJSONArray("cmds");
            if (cmds == null) continue;
            for (int j = 0; j < cmds.length(); j++) {
                JSONObject c = cmds.optJSONObject(j);
                if (c == null) continue;
                String tpl = c.optString("s");
                if (tpl.isEmpty()) tpl = c.optString("template");
                if (tpl.isEmpty()) continue;
                JSONObject o2 = new JSONObject();
                try {
                    o2.put("n", c.optString("n"));
                    o2.put("s", tpl);
                    if (c.has("args")) o2.put("args", c.optJSONArray("args"));
                } catch (Exception ignored) {}
                out.add(new Models.Template(o2));
            }
        }
        return out;
    }

    /** 已开启 ID 源（type=id） */
    public List<Models.IdEntry> sourceIds() {
        List<Models.IdEntry> out = new ArrayList<>();
        JSONArray a = getSources();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !o.optBoolean("enabled", true)) continue;
            if (!"id".equals(o.optString("type", "preset"))) continue;
            JSONArray cmds = o.optJSONArray("cmds");
            if (cmds == null) continue;
            for (int j = 0; j < cmds.length(); j++) {
                JSONObject c = cmds.optJSONObject(j);
                if (c == null) continue;
                String id = c.optString("id");
                String n = c.optString("n");
                if (n.isEmpty()) n = c.optString("name");
                if (id.isEmpty()) continue;
                String note = c.optString("note");
                if (note.isEmpty()) note = c.optString("d");
                out.add(new Models.IdEntry("来源", id, n, note));
            }
        }
        return out;
    }

    /** 指定类型的源总条数 */
    public int srcCount(String type) {
        int n = 0;
        JSONArray a = getSources();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (!type.equals(o.optString("type", "preset"))) continue;
            JSONArray cmds = o.optJSONArray("cmds");
            if (cmds != null) n += cmds.length();
        }
        return n;
    }

    public int sourceCount() { return srcCount("preset"); }
}
