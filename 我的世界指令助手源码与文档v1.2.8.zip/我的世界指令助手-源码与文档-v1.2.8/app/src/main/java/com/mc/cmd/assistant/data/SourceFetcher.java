package com.mc.cmd.assistant.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** 命令源获取与解析：支持三类源并自动检测类型
 *  拼接源（模板 template）、预览源（预设命令 preset）、ID源（id） */
public class SourceFetcher {

    private static final int MAX = 500;

    public static class Result {
        public String type = "preset"; // preset | template | id
        public List<Models.Preset> presets = new ArrayList<>();
        public List<Models.Template> templates = new ArrayList<>();
        public List<Models.IdEntry> ids = new ArrayList<>();
        public int count() {
            return presets.size() + templates.size() + ids.size();
        }
    }

    public static Result fetch(String urlStr) throws Exception {
        if (urlStr == null || urlStr.trim().isEmpty()) throw new Exception("URL 为空");
        String u = urlStr.trim();
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;

        HttpURLConnection conn = (HttpURLConnection) new URL(u).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(20000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) MC-Command-Assistant/1.2.0");
        int code = conn.getResponseCode();
        if (code != 200) {
            conn.disconnect();
            throw new Exception("HTTP " + code);
        }
        InputStream is = conn.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        is.close();
        conn.disconnect();
        String text = sb.toString().trim();

        Result r = new Result();
        // 优先尝试 JSON
        try {
            JSONArray arr = findArray(text);
            if (arr != null) {
                for (int i = 0; i < arr.length() && r.count() < MAX; i++) {
                    Object o = arr.opt(i);
                    if (o instanceof String) {
                        String c = ((String) o).trim();
                        if (c.isEmpty()) continue;
                        r.presets.add(new Models.Preset("命令源", c, ""));
                    } else if (o instanceof JSONObject) {
                        JSONObject j = (JSONObject) o;
                        addEntry(r, j);
                    }
                }
            }
        } catch (Exception ignored) {}

        // JSON 解析失败或无数组 → 按文本行解析（默认预设命令）
        if (r.count() == 0) {
            for (String ln : text.split("\\r?\\n")) {
                String l = ln.trim();
                if (l.isEmpty() || l.startsWith("#") || l.startsWith("//")) continue;
                if (r.count() >= MAX) break;
                String cmd = l;
                String d = "";
                for (String sep : new String[]{" —— ", " — ", " - ", "：", ":", "\t"}) {
                    int idx = l.indexOf(sep);
                    if (idx > 0) {
                        String head = l.substring(0, idx).trim();
                        String tail = l.substring(idx + sep.length()).trim();
                        if (!head.isEmpty()) { cmd = head; d = tail; }
                        break;
                    }
                }
                r.presets.add(new Models.Preset("命令源", cmd, d));
            }
        }

        // 自动判定类型：按条目数量投票，平局优先级 preset > template > id
        int p = r.presets.size(), t = r.templates.size(), i = r.ids.size();
        if (t > p && t >= i) r.type = "template";
        else if (i > p && i > t) r.type = "id";
        else r.type = "preset";
        return r;
    }

    private static void addEntry(Result r, JSONObject j) {
        // 拼接模板：有模板串字段
        String tpl = firstNonEmpty(j, "s", "template", "tpl", "模板");
        if (tpl != null && !tpl.trim().isEmpty()) {
            String name = firstNonEmpty(j, "n", "name", "title", "名称", "名字");
            if (name == null || name.isEmpty()) name = "模板 " + (r.templates.size() + 1);
            JSONObject o = new JSONObject();
            try {
                o.put("n", name);
                o.put("s", tpl.trim());
                String hint = firstNonEmpty(j, "h", "hint", "d", "desc", "description", "说明");
                if (hint != null && !hint.isEmpty()) o.put("d", hint);
                if (j.has("args")) o.put("args", j.optJSONArray("args"));
            } catch (Exception ignored) {}
            r.templates.add(new Models.Template(o));
            return;
        }
        // ID 条目：有 id 且 (n 或 name)
        String id = firstNonEmpty(j, "id", "item", "entity", "物品", "实体");
        String nm = firstNonEmpty(j, "n", "name", "名称", "名字");
        if (id != null && !id.trim().isEmpty() && nm != null && !nm.trim().isEmpty()) {
            String note = firstNonEmpty(j, "note", "d", "desc", "description", "说明");
            r.ids.add(new Models.IdEntry("来源", id.trim(), nm.trim(), note == null ? "" : note));
            return;
        }
        // 预设命令
        String c = firstNonEmpty(j, "cmd", "command", "c", "指令", "命令");
        if (c == null || c.trim().isEmpty()) c = nm;
        if (c == null || c.trim().isEmpty()) return;
        String d = firstNonEmpty(j, "d", "desc", "description", "note", "简介", "说明");
        r.presets.add(new Models.Preset("命令源", c.trim(), d == null ? "" : d));
    }

    private static JSONArray findArray(String text) {
        JSONObject obj = null;
        try {
            obj = new JSONObject(text);
        } catch (Exception ignored) {}
        if (obj != null) {
            for (String k : new String[]{"templates", "presets", "commands", "cmds", "ids", "items", "data", "list", "sources"}) {
                Object o = obj.opt(k);
                if (o instanceof JSONArray) return (JSONArray) o;
            }
            return null;
        }
        try {
            JSONArray arr = new JSONArray(text);
            return arr;
        } catch (Exception ignored) {}
        return null;
    }

    private static String firstNonEmpty(JSONObject j, String... keys) {
        for (String k : keys) {
            String v = j.optString(k);
            if (v != null && !v.isEmpty()) return v;
        }
        return null;
    }
}
