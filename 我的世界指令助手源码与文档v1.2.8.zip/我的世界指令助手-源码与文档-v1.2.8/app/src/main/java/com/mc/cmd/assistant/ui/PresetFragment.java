package com.mc.cmd.assistant.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Models.Preset;
import com.mc.cmd.assistant.data.Prefs;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class PresetFragment extends Fragment {

    private String cat = "全部";
    private List<Preset> all = new ArrayList<>();
    private HotAdapter adapter;
    private boolean sourceCatAdded;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_preset, container, false);
        buildCats(v);
        RecyclerView rv = v.findViewById(R.id.presetList);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new HotAdapter(filtered());
        rv.setAdapter(adapter);
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        View v = getView();
        if (v != null) {
            buildCats(v);
            apply();
        }
    }

    private void buildCats(View v) {
        DataStore ds = DataStore.get();
        Prefs prefs = new Prefs(requireContext());
        all = new ArrayList<>();
        if (prefs.getBuiltinEnabled()) all.addAll(ds.presets);
        all.addAll(prefs.sourcePresets());
        ((TextView) v.findViewById(R.id.presetCount)).setText(getString(R.string.preset_count_hint, all.size()));

        Set<String> cats = new LinkedHashSet<>();
        cats.add("全部");
        if (prefs.getBuiltinEnabled()) for (Preset p : ds.presets) cats.add(p.c);
        if (prefs.sourceCount() > 0) cats.add(getString(R.string.preset_source_cat));

        ChipGroup cg = v.findViewById(R.id.presetCats);
        cg.removeAllViews();
        for (String c : cats) {
            Chip chip = new Chip(requireContext());
            chip.setText(c);
            chip.setCheckable(true);
            chip.setTag(c);
            chip.setOnClickListener(x -> {
                cat = (String) chip.getTag();
                for (int i = 0; i < cg.getChildCount(); i++) {
                    Chip ch = (Chip) cg.getChildAt(i);
                    ch.setChecked(cat.equals(ch.getTag()));
                }
                apply();
            });
            cg.addView(chip);
            if (cat.equals(c)) chip.setChecked(true);
        }
        if (cg.getChildCount() > 0 && !((Chip) cg.getChildAt(0)).isChecked()) {
            ((Chip) cg.getChildAt(0)).setChecked(true);
            cat = "全部";
        }
        sourceCatAdded = prefs.sourceCount() > 0;
    }

    private List<Preset> filtered() {
        String sourceCat = getString(R.string.preset_source_cat);
        if ("全部".equals(cat)) return all;
        List<Preset> out = new ArrayList<>();
        for (Preset p : all) {
            if (cat.equals(p.c)) out.add(p);
            else if (cat.equals(sourceCat) && "命令源".equals(p.c)) out.add(p);
        }
        return out;
    }

    private void apply() {
        adapter = new HotAdapter(filtered());
        RecyclerView rv = getView() == null ? null : getView().findViewById(R.id.presetList);
        if (rv != null) rv.setAdapter(adapter);
    }
}
