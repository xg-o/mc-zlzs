package com.mc.cmd.assistant;

import android.content.Context;
import android.content.Intent;

import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.RunLog;
import com.mc.cmd.assistant.util.LangUtil;

public class App extends android.app.Application {
    private static App instance;

    @Override
    public void onCreate() {
        super.onCreate();
        DataStore.init(this);
        instance = this;
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                RunLog.log(App.this, RunLog.T_CRASH, RunLog.stack(e));
            } catch (Exception ignored) {}
            if (prev != null) prev.uncaughtException(t, e);
        });
        RunLog.log(this, RunLog.T_APP, "应用启动 v1.2.8");
    }

    public static Context ctx() {
        return instance;
    }

    /** 全局语言/主题修改后：重建整个任务栈，保证所有页面生效 */
    public static void restart(Context c) {
        try {
            Intent i = new Intent(c, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            c.startActivity(i);
        } catch (Exception ignored) {}
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LangUtil.wrap(base));
        instance = this;
    }
}
