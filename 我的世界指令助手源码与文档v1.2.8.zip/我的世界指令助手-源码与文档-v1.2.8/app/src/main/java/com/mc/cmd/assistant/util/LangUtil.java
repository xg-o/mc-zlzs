package com.mc.cmd.assistant.util;

import android.content.Context;
import android.content.res.Configuration;

import com.mc.cmd.assistant.data.Prefs;

import java.util.Locale;

/** 应用内语言切换：跟随系统 / 简 / 繁 / en / fr / ja */
public class LangUtil {

    public static Context wrap(Context base) {
        String lang = new Prefs(base).getLang();
        if (lang == null || lang.isEmpty() || "system".equals(lang)) return base;
        Locale l;
        switch (lang) {
            case "zh": l = Locale.SIMPLIFIED_CHINESE; break;
            case "zh-rTW": l = Locale.TRADITIONAL_CHINESE; break;
            case "en": l = Locale.ENGLISH; break;
            case "fr": l = Locale.FRENCH; break;
            case "ja": l = Locale.JAPANESE; break;
            default: return base;
        }
        Locale.setDefault(l);
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(l);
        return base.createConfigurationContext(cfg);
    }
}
