package com.mc.cmd.assistant.ui;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.mc.cmd.assistant.App;
import com.mc.cmd.assistant.BaseActivity;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.util.ThemeUtil;

/** 外观：主题配色（预设 + 自定义）与语言切换 */
public class AppearanceActivity extends BaseActivity {

    private Prefs prefs;
    private final int[] customPalette = {
            0xFF6750A4, 0xFF2E7D32, 0xFF1565C0, 0xFFE65100,
            0xFFC62828, 0xFFC2185B, 0xFF00838F, 0xFF5D4037,
            0xFFF9A825, 0xFF283593, 0xFF00695C, 0xFF37474F
    };
    private String selCustom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appearance);
        prefs = new Prefs(this);
        ((MaterialToolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(x -> finish());

        String cur = prefs.getTheme();
        selCustom = prefs.getThemeCustom();

        LinearLayout row = findViewById(R.id.themeRow);
        String[] ids = ThemeUtil.THEME_IDS;
        int[] seeds = ThemeUtil.THEME_SEEDS;
        for (int i = 0; i < ids.length; i++) {
            final String id = ids[i];
            final int seed = seeds[i];
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            item.setPadding(dp(8), dp(4), dp(8), dp(4));

            View circle = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
            lp.bottomMargin = dp(6);
            circle.setLayoutParams(lp);
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            gd.setColor(seed);
            gd.setStroke(dp(2), id.equals(cur) ? 0xFF000000 : 0x33000000);
            circle.setBackground(gd);
            item.addView(circle);

            TextView label = new TextView(this);
            int nameRes = nameRes(id);
            label.setText(nameRes);
            label.setTextSize(11f);
            label.setTextColor(id.equals(cur) ? getColor(android.R.color.holo_purple) : 0xFF888888);
            item.addView(label);

            final String tag = id;
            item.setOnClickListener(x -> {
                prefs.setTheme(tag);
                if (!"custom".equals(tag)) {
                    selCustom = "";
                    prefs.setThemeCustom("");
                }
                App.restart(this);
            });
            row.addView(item);
        }

        findViewById(R.id.customLabel).setOnClickListener(x -> togglePalette());
        findViewById(R.id.customHex).setOnClickListener(x -> togglePalette());
        ((TextView) findViewById(R.id.customHex)).setText(selCustom.isEmpty() ? "" : selCustom);

        LinearLayout palette = findViewById(R.id.customPalette);
        for (int c : customPalette) {
            final int color = c;
            View v = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(38), dp(38));
            lp.setMarginEnd(dp(10));
            v.setLayoutParams(lp);
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            gd.setColor(color);
            v.setBackground(gd);
            v.setOnClickListener(x -> {
                String hex = String.format("#%06X", color & 0xFFFFFF);
                selCustom = hex;
                prefs.setThemeCustom(hex);
                prefs.setTheme("custom");
                ((TextView) findViewById(R.id.customHex)).setText(hex);
                App.restart(this);
            });
            palette.addView(v);
        }

        LinearLayout langList = findViewById(R.id.langList);
        String[][] langs = {
                {"system", getString(R.string.lang_system)},
                {"zh", getString(R.string.lang_zh)},
                {"zh-rTW", getString(R.string.lang_zh_tw)},
                {"en", getString(R.string.lang_en)},
                {"fr", getString(R.string.lang_fr)},
                {"ja", getString(R.string.lang_ja)},
        };
        String curLang = prefs.getLang();
        for (String[] lg : langs) {
            MaterialButton b = new MaterialButton(this);
            b.setText(lg[1]);
            b.setAllCaps(false);
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            b.setPadding(dp(16), 0, dp(16), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
            lp.bottomMargin = dp(6);
            b.setLayoutParams(lp);
            if (lg[0].equals(curLang)) {
                b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ThemeUtil.resolveColor(this, "colorPrimaryContainer")));
                b.setTextColor(ThemeUtil.resolveColor(this, "colorOnPrimaryContainer"));
            } else {
                b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0x00000000));
                b.setStrokeColor(android.content.res.ColorStateList.valueOf(ThemeUtil.resolveColor(this, "colorOutline")));
                b.setStrokeWidth(dp(1));
                b.setTextColor(ThemeUtil.resolveColor(this, "colorOnSurfaceVariant"));
            }
            final String code = lg[0];
            b.setOnClickListener(x -> {
                prefs.setLang(code);
                Toast.makeText(this, R.string.st_saved, Toast.LENGTH_SHORT).show();
                App.restart(this);
            });
            langList.addView(b);
        }
    }

    private int nameRes(String id) {
        switch (id) {
            case "green": return R.string.ap_theme_green;
            case "blue": return R.string.ap_theme_blue;
            case "orange": return R.string.ap_theme_orange;
            case "red": return R.string.ap_theme_red;
            case "pink": return R.string.ap_theme_pink;
            case "custom": return R.string.ap_theme_custom;
            default: return R.string.ap_theme_purple;
        }
    }

    private void togglePalette() {
        View p = findViewById(R.id.customPalette);
        p.setVisibility(p.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
