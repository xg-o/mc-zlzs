package com.mc.cmd.assistant.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.Prefs;

import org.json.JSONObject;

import java.util.List;

/** 收藏条目列表（type=id 时为 ID，type=preset/custom 时为命令） */
public class FavAdapter extends RecyclerView.Adapter<FavAdapter.VH> {
    private final List<JSONObject> items;
    private final Runnable onChanged;

    public FavAdapter(List<JSONObject> items, Runnable onChanged) {
        this.items = items;
        this.onChanged = onChanged;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_fav, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        JSONObject o = items.get(pos);
        String cmd = o.optString("cmd");
        String ref = o.optString("ref");
        String type = o.optString("type");
        String label = o.optString("label");
        String sub = o.optString("sub");
        String display = cmd.isEmpty() ? ref : cmd;
        h.cmd.setText(display);
        StringBuilder sb = new StringBuilder();
        if (!label.isEmpty()) sb.append(label);
        if (!sub.isEmpty() && !sub.equals(label)) {
            if (sb.length() > 0) sb.append(" · ");
            sb.append(sub);
        }
        h.label.setText(sb.toString());
        h.copy.setOnClickListener(x -> Clip.copy(h.itemView.getContext(), display));
        h.remove.setOnClickListener(x -> {
            new Prefs(h.itemView.getContext()).removeFav(type, ref);
            if (onChanged != null) onChanged.run();
        });
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView cmd, label;
        ImageButton copy, remove;

        VH(@NonNull View v) {
            super(v);
            cmd = v.findViewById(R.id.favCmd);
            label = v.findViewById(R.id.favLabel);
            copy = v.findViewById(R.id.favCopy);
            remove = v.findViewById(R.id.favRemove);
        }
    }
}
