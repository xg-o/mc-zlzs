package com.mc.cmd.assistant.data;

import android.content.Context;
import android.content.res.AssetManager;

import com.mc.cmd.assistant.data.Models.Preset;
import com.mc.cmd.assistant.data.Models.Template;
import com.mc.cmd.assistant.data.Models.Arg;
import com.mc.cmd.assistant.data.Models.IdEntry;
import com.mc.cmd.assistant.data.Models.Provider;
import com.mc.cmd.assistant.data.Models.SearchResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** 全局数据仓库：解析 assets/data.json，提供预设/模板/ID/搜索/命令构建 */
public class DataStore {
    private static DataStore inst;

    public static void init(Context c) {
        if (inst == null) inst = new DataStore(c);
    }
    public static DataStore get() { return inst; }

    public final List<Preset> presets = new ArrayList<>();
    public final List<Template> templates = new ArrayList<>();
    public final Map<String, List<IdEntry>> ids = new LinkedHashMap<>();
    public final List<String[]> idCats = new ArrayList<>();     // {k, l}
    public final Map<String, String> idCatHints = new LinkedHashMap<>();
    public final List<Provider> providers = new ArrayList<>();
    public String defaultPrompt = "";

    private DataStore(Context c) {
        try {
            AssetManager am = c.getAssets();
            InputStream is = am.open("data.json");
            byte[] buf = new byte[is.available()];
            int off = 0;
            while (off < buf.length) {
                int r = is.read(buf, off, buf.length - off);
                if (r < 0) break;
                off += r;
            }
            is.close();
            String json = new String(buf, StandardCharsets.UTF_8);
            JSONObject root = new JSONObject(json);

            JSONArray pa = root.optJSONArray("presets");
            if (pa != null) for (int i = 0; i < pa.length(); i++) presets.add(new Preset(pa.optJSONObject(i)));

            JSONArray ta = root.optJSONArray("templates");
            if (ta != null) for (int i = 0; i < ta.length(); i++) templates.add(new Template(ta.optJSONObject(i)));

            JSONObject ido = root.optJSONObject("ids");
            if (ido != null) {
                JSONArray names = ido.names();
                for (int i = 0; i < names.length(); i++) {
                    String cat = names.optString(i);
                    JSONArray arr = ido.optJSONArray(cat);
                    List<IdEntry> list = new ArrayList<>();
                    if (arr != null) for (int j = 0; j < arr.length(); j++) {
                        JSONArray e = arr.optJSONArray(j);
                        if (e != null && e.length() >= 1) {
                            list.add(new IdEntry(cat, e.optString(0), e.optString(1), e.length() > 2 ? e.optString(2) : ""));
                        }
                    }
                    ids.put(cat, list);
                }
            }

            JSONArray ica = root.optJSONArray("idcats");
            if (ica != null) for (int i = 0; i < ica.length(); i++) {
                JSONObject o = ica.optJSONObject(i);
                idCats.add(new String[]{o.optString("k"), o.optString("l")});
            }

            JSONObject ih = root.optJSONObject("icatHints");
            if (ih != null) {
                JSONArray hn = ih.names();
                for (int i = 0; i < hn.length(); i++) idCatHints.put(hn.optString(i), ih.optString(hn.optString(i)));
            }

            JSONArray pra = root.optJSONArray("providers");
            if (pra != null) for (int i = 0; i < pra.length(); i++) providers.add(new Provider(pra.optJSONObject(i)));

            defaultPrompt = root.optString("defaultPrompt");
        } catch (Exception e) {
            android.util.Log.e("DataStore", "load fail", e);
        }
    }

    public int idTotal() {
        int n = 0;
        for (List<IdEntry> l : ids.values()) n += l.size();
        return n;
    }

    public List<IdEntry> flatIds() {
        List<IdEntry> out = new ArrayList<>();
        for (List<IdEntry> l : ids.values()) out.addAll(l);
        return out;
    }

    public List<String> sugPool(String pool) {
        List<String> out = new ArrayList<>();
        if (pool == null) return out;
        switch (pool) {
            case "effect": for (IdEntry e : ids.getOrDefault("effects", new ArrayList<>())) out.add(e.id); break;
            case "entity": for (IdEntry e : ids.getOrDefault("entities", new ArrayList<>())) out.add(e.id.replace("minecraft:", "")); break;
            case "particle": for (IdEntry e : ids.getOrDefault("particles", new ArrayList<>())) out.add(e.id); break;
            case "sound": for (IdEntry e : ids.getOrDefault("sounds", new ArrayList<>())) out.add(e.id); break;
            case "ench": for (IdEntry e : ids.getOrDefault("enchants", new ArrayList<>())) out.add(e.id); break;
            case "rule": for (IdEntry e : ids.getOrDefault("rules", new ArrayList<>())) out.add(e.id); break;
            case "id": for (IdEntry e : flatIds()) out.add(e.id.replace("minecraft:", "")); break;
            default: break;
        }
        return out;
    }

    public Template templateById(String id) {
        for (Template t : templates) if (t.id.equals(id)) return t;
        return templates.isEmpty() ? null : templates.get(0);
    }

    /** 构建命令：/前缀 + 固定段 + 参数值 */
    public String buildCommand(String tplId, Map<String, String> values) {
        Template t = templateById(tplId);
        if (t == null) return "";
        StringBuilder sb = new StringBuilder("/");
        sb.append(String.join(" ", t.cmd));
        for (Arg a : t.args) {
            String v = values.get(a.k);
            v = v == null ? "" : v.trim();
            if (v.isEmpty()) {
                if (a.opt) continue;
                sb.append(' ').append(a.d == null || a.d.isEmpty() ? "<" + a.l + ">" : a.d);
            } else {
                sb.append(' ').append(v);
            }
        }
        return sb.toString();
    }

    public SearchResult search(String q) {
        SearchResult r = new SearchResult();
        if (q == null) return r;
        String qq = q.trim().toLowerCase(Locale.ROOT);
        if (qq.isEmpty()) return r;
        for (Preset p : presets) {
            if (p.cmd.toLowerCase(Locale.ROOT).contains(qq) || p.d.toLowerCase(Locale.ROOT).contains(qq)
                    || p.c.toLowerCase(Locale.ROOT).contains(qq)) r.presets.add(p);
        }
        for (Map.Entry<String, List<IdEntry>> en : ids.entrySet()) {
            for (IdEntry e : en.getValue()) {
                if (e.id.toLowerCase(Locale.ROOT).contains(qq)
                        || (e.name != null && e.name.toLowerCase(Locale.ROOT).contains(qq))
                        || (e.note != null && e.note.toLowerCase(Locale.ROOT).contains(qq))) r.ids.add(e);
            }
        }
        for (Template t : templates) {
            if (t.n.toLowerCase(Locale.ROOT).contains(qq) || t.s.toLowerCase(Locale.ROOT).contains(qq)) r.templates.add(t);
        }
        return r;
    }

    /** 从 AI 回复中提取 / 开头的命令行 */
    public static List<String> extractCmds(String text) {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        for (String line : text.split("\n")) {
            String t = line.trim();
            if (t.startsWith("/")) out.add(t);
        }
        return out;
    }
}
