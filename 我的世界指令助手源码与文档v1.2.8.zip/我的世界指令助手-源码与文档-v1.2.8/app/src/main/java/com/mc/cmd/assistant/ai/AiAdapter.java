package com.mc.cmd.assistant.ai;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Prefs;

import java.util.List;

public class AiAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static class Msg {
        public final boolean isUser;
        public final String text;

        public Msg(boolean isUser, String text) {
            this.isUser = isUser;
            this.text = text;
        }
    }

    private final List<Msg> msgs;

    public AiAdapter(List<Msg> msgs) { this.msgs = msgs; }

    @Override
    public int getItemViewType(int pos) { return msgs.get(pos).isUser ? 0 : 1; }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater li = LayoutInflater.from(parent.getContext());
        return viewType == 0 ? new UserVH(li.inflate(R.layout.item_chat_user, parent, false))
                : new AiVH(li.inflate(R.layout.item_chat_ai, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int pos) {
        Msg m = msgs.get(pos);
        if (h instanceof UserVH) {
            ((UserVH) h).tv.setText(m.text);
        } else {
            AiVH vh = (AiVH) h;
            vh.tv.setText(m.text);
            vh.cmds.removeAllViews();
            List<String> cmds = DataStore.get().extractCmds(m.text);
            Prefs prefs = new Prefs(vh.itemView.getContext());
            for (String c : cmds) {
                LinearLayout row = new LinearLayout(vh.itemView.getContext());
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                row.setBackgroundResource(R.drawable.bg_cmd_line);
                row.setPadding(dp(vh, 10), dp(vh, 4), dp(vh, 4), dp(vh, 4));
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rp.bottomMargin = dp(vh, 6);
                row.setLayoutParams(rp);

                TextView code = new TextView(vh.itemView.getContext());
                code.setText(c);
                code.setTextSize(12.5f);
                code.setTypeface(android.graphics.Typeface.MONOSPACE);
                code.setTextColor(vh.itemView.getContext().getColor(R.color.md_primary));
                code.setPadding(dp(vh, 4), 0, dp(vh, 8), 0);
                code.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                row.addView(code);

                ImageButton copy = icon(vh, R.drawable.ic_copy);
                copy.setOnClickListener(x -> Clip.copy(vh.itemView.getContext(), c));
                row.addView(copy);

                ImageButton save = icon(vh, R.drawable.ic_star);
                save.setOnClickListener(x -> {
                    boolean on = prefs.toggleFav("custom", "ai|" + c, "AI · " + c, c, "AI 生成");
                    Toast.makeText(vh.itemView.getContext(), on ? R.string.fav_added : R.string.fav_removed, Toast.LENGTH_SHORT).show();
                });
                row.addView(save);

                ImageButton book = icon(vh, R.drawable.ic_book);
                book.setOnClickListener(x -> {
                    prefs.saveCmd(c);
                    Toast.makeText(vh.itemView.getContext(), R.string.ai_saved_book, Toast.LENGTH_SHORT).show();
                });
                row.addView(book);

                vh.cmds.addView(row);
            }
        }
    }

    private int dp(RecyclerView.ViewHolder h, int v) {
        return Math.round(v * h.itemView.getContext().getResources().getDisplayMetrics().density);
    }

    private ImageButton icon(RecyclerView.ViewHolder h, int res) {
        ImageButton b = new ImageButton(h.itemView.getContext());
        b.setImageResource(res);
        b.setBackground(null);
        b.setPadding(dp(h, 10), dp(h, 8), dp(h, 10), dp(h, 8));
        b.setImageTintList(android.content.res.ColorStateList.valueOf(h.itemView.getContext().getColor(R.color.md_primary)));
        return b;
    }

    @Override
    public int getItemCount() { return msgs.size(); }

    static class UserVH extends RecyclerView.ViewHolder {
        TextView tv;

        UserVH(@NonNull View v) {
            super(v);
            tv = v.findViewById(R.id.chatUser);
        }
    }

    static class AiVH extends RecyclerView.ViewHolder {
        TextView tv;
        LinearLayout cmds;

        AiVH(@NonNull View v) {
            super(v);
            tv = v.findViewById(R.id.chatAiText);
            cmds = v.findViewById(R.id.chatCmds);
        }
    }
}
