package com.mc.cmd.assistant.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.Models.IdEntry;
import com.mc.cmd.assistant.data.Models.Preset;
import com.mc.cmd.assistant.data.Prefs;

import java.util.List;

/** 搜索结果：Preset（命令）与 IdEntry（ID）混排 */
public class SearchAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<Object> items;

    public SearchAdapter(List<Object> items) { this.items = items; }

    @Override
    public int getItemViewType(int pos) { return items.get(pos) instanceof Preset ? 0 : 1; }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater li = LayoutInflater.from(parent.getContext());
        return viewType == 0 ? new PresetVH(li.inflate(R.layout.item_preset, parent, false))
                : new IdVH(li.inflate(R.layout.item_id, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int pos) {
        Object o = items.get(pos);
        Prefs prefs = new Prefs(h.itemView.getContext());
        if (h instanceof PresetVH) {
            Preset p = (Preset) o;
            PresetVH vh = (PresetVH) h;
            vh.cmd.setText(p.cmd);
            vh.desc.setText((p.c == null ? "" : p.c) + (p.d == null || p.d.isEmpty() ? "" : " · " + p.d));
            if ("命令源".equals(p.c)) {
                vh.compat.setText(R.string.src_compat_hint);
            } else {
                String line = vh.itemView.getContext().getString(R.string.compat_line, Preset.VER_BEDROCK);
                String uv = prefs.getMcVersion();
                if (uv != null && !uv.isEmpty()) {
                    line += " · " + (Preset.inRange(uv)
                            ? vh.itemView.getContext().getString(R.string.compat_ok, uv)
                            : vh.itemView.getContext().getString(R.string.compat_bad, uv));
                }
                vh.compat.setText(line);
            }
            String ref = "preset|" + p.cmd;
            vh.star.setImageResource(prefs.isFav("preset", ref) ? R.drawable.ic_star_filled : R.drawable.ic_star);
            vh.star.setOnClickListener(x -> {
                boolean on = prefs.toggleFav("preset", ref, p.d, p.cmd, p.c);
                vh.star.setImageResource(on ? R.drawable.ic_star_filled : R.drawable.ic_star);
                Toast.makeText(vh.itemView.getContext(), on ? R.string.fav_added : R.string.fav_removed, Toast.LENGTH_SHORT).show();
            });
            vh.copy.setOnClickListener(x -> Clip.copy(vh.itemView.getContext(), p.cmd));
            vh.itemView.setOnClickListener(x -> Clip.copy(vh.itemView.getContext(), p.cmd));
        } else {
            IdEntry e = (IdEntry) o;
            IdVH vh = (IdVH) h;
            vh.id.setText(e.id);
            vh.name.setText(e.name == null ? "" : e.name);
            vh.note.setText(e.note == null ? "" : e.note);
            String ref = e.cat + "|" + e.id;
            vh.star.setImageResource(prefs.isFav("id", ref) ? R.drawable.ic_star_filled : R.drawable.ic_star);
            vh.star.setOnClickListener(x -> {
                boolean on = prefs.toggleFav("id", ref, e.name, e.id, e.note);
                vh.star.setImageResource(on ? R.drawable.ic_star_filled : R.drawable.ic_star);
                Toast.makeText(vh.itemView.getContext(), on ? R.string.fav_added : R.string.fav_removed, Toast.LENGTH_SHORT).show();
            });
            vh.copy.setOnClickListener(x -> Clip.copy(vh.itemView.getContext(), e.id));
            vh.itemView.setOnClickListener(x -> Clip.copy(vh.itemView.getContext(), e.id));
        }
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class PresetVH extends RecyclerView.ViewHolder {
        TextView cmd, desc, compat;
        ImageButton copy, star;

        PresetVH(@NonNull View v) {
            super(v);
            cmd = v.findViewById(R.id.itemCmd);
            desc = v.findViewById(R.id.itemDesc);
            compat = v.findViewById(R.id.itemCompat);
            copy = v.findViewById(R.id.itemCopy);
            star = v.findViewById(R.id.itemStar);
        }
    }

    static class IdVH extends RecyclerView.ViewHolder {
        TextView id, name, note;
        ImageButton copy, star;

        IdVH(@NonNull View v) {
            super(v);
            id = v.findViewById(R.id.idv);
            name = v.findViewById(R.id.idName);
            note = v.findViewById(R.id.idNote);
            copy = v.findViewById(R.id.idCopy);
            star = v.findViewById(R.id.idStar);
        }
    }
}
