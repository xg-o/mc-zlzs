package com.mc.cmd.assistant.ui;

import android.content.Context;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Prefs;

/** 我的世界版本信息设置（首次启动向导 / 我的页重新设置） */
public class VersionDialog {

    public static void show(Context c, Prefs prefs, Runnable onDone) {
        FrameLayout wrap = new FrameLayout(c);
        int pad = dp(c, 20);
        wrap.setPadding(pad, dp(c, 6), pad, 0);

        LinearLayout ll = new LinearLayout(c);
        ll.setOrientation(LinearLayout.VERTICAL);

        TextView pt = new TextView(c);
        pt.setText(R.string.onboard_platform);
        pt.setTextSize(13.5f);
        pt.setTextColor(0xFF666666);
        ll.addView(pt);

        ChipGroup platform = new ChipGroup(c);
        platform.setSingleSelection(true);
        String[][] plats = {{"bedrock", c.getString(R.string.onboard_platform_bedrock)},
                {"java", c.getString(R.string.onboard_platform_java)}};
        for (String[] p : plats) {
            Chip chip = new Chip(c);
            chip.setText(p[1]);
            chip.setCheckable(true);
            chip.setTag(p[0]);
            if ("bedrock".equals(p[0])) chip.setChecked(true);
            platform.addView(chip);
        }
        ll.addView(platform);

        TextView dt = new TextView(c);
        dt.setText(R.string.onboard_device);
        dt.setTextSize(13.5f);
        dt.setTextColor(0xFF666666);
        dt.setPadding(0, dp(c, 10), 0, 0);
        ll.addView(dt);

        ChipGroup device = new ChipGroup(c);
        device.setSingleSelection(true);
        String[][] devs = {{"mobile", c.getString(R.string.onboard_device_mobile)},
                {"pc", c.getString(R.string.onboard_device_pc)}};
        for (String[] d : devs) {
            Chip chip = new Chip(c);
            chip.setText(d[1]);
            chip.setCheckable(true);
            chip.setTag(d[0]);
            if ("mobile".equals(d[0])) chip.setChecked(true);
            device.addView(chip);
        }
        ll.addView(device);

        TextView vt = new TextView(c);
        vt.setText(R.string.onboard_version);
        vt.setTextSize(13.5f);
        vt.setTextColor(0xFF666666);
        vt.setPadding(0, dp(c, 10), 0, 0);
        ll.addView(vt);

        EditText ver = new EditText(c);
        ver.setSingleLine(true);
        ver.setText(prefs.getMcVersion().isEmpty() ? "1.26.45.1" : prefs.getMcVersion());
        ll.addView(ver);

        TextView hint = new TextView(c);
        hint.setText(R.string.version_hint);
        hint.setTextSize(11.5f);
        hint.setTextColor(0xFF999999);
        hint.setPadding(0, dp(c, 4), 0, 0);
        ll.addView(hint);

        wrap.addView(ll);

        new AlertDialog.Builder(c)
                .setTitle(R.string.onboard_mc_title)
                .setView(wrap)
                .setPositiveButton(R.string.ok, (d, w) -> {
                    String plat = "bedrock";
                    for (int i = 0; i < platform.getChildCount(); i++) {
                        Chip ch = (Chip) platform.getChildAt(i);
                        if (ch.isChecked()) plat = (String) ch.getTag();
                    }
                    String dev = "mobile";
                    for (int i = 0; i < device.getChildCount(); i++) {
                        Chip ch = (Chip) device.getChildAt(i);
                        if (ch.isChecked()) dev = (String) ch.getTag();
                    }
                    String v = ver.getText() == null ? "" : ver.getText().toString().trim();
                    if (v.isEmpty()) v = "1.26.45.1";
                    prefs.setMcInfo(plat, dev, v);
                    String platLabel = "bedrock".equals(plat) ? c.getString(R.string.onboard_platform_bedrock) : c.getString(R.string.onboard_platform_java);
                    Toast.makeText(c, c.getString(R.string.onboard_done, platLabel, v), Toast.LENGTH_LONG).show();
                    if (onDone != null) onDone.run();
                })
                .setNegativeButton(R.string.onboard_skip, (d, w) -> {
                    if (onDone != null) onDone.run();
                })
                .show();
    }

    private static int dp(Context c, int v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
}
