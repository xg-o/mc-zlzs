package com.mc.cmd.assistant.ai;

import com.mc.cmd.assistant.App;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Models.Provider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** OpenAI 兼容接口调用（HttpURLConnection，无第三方依赖） */
public class AiClient {

    public static String resolveBase(JSONObject st, List<Provider> providers) {
        String b = st.optString("baseURL");
        if (b != null && !b.isEmpty()) return b.trim();
        for (Provider p : providers) if (p.id.equals(st.optString("provider"))) return p.base;
        return "";
    }

    private static HttpURLConnection open(String base, JSONObject st, String body) throws Exception {
        URL url = new URL(base);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setRequestProperty("Content-Type", "application/json");
        String key = st.optString("apiKey");
        if (key != null && !key.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + key);
        try {
            String extra = st.optString("extraHeaders");
            if (extra != null && !extra.isEmpty()) {
                JSONObject h = new JSONObject(extra);
                JSONArray names = h.names();
                for (int i = 0; i < names.length(); i++) {
                    String n = names.optString(i);
                    c.setRequestProperty(n, h.optString(n));
                }
            }
        } catch (Exception ignored) {}
        c.setDoOutput(true);
        OutputStream os = c.getOutputStream();
        os.write(body.getBytes(StandardCharsets.UTF_8));
        os.close();
        return c;
    }

    /** 发一条消息，返回 AI 回复文本；失败抛异常 */
    public static String chat(String base, JSONObject st, JSONArray messages) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", st.optString("model", "deepseek-chat"));
        body.put("messages", messages);
        body.put("temperature", st.optDouble("temperature", 0.7));
        body.put("max_tokens", 1600);
        HttpURLConnection c = open(base, st, body.toString());
        int code = c.getResponseCode();
        if (code != 200) {
            String err = read(c.getErrorStream());
            throw new Exception("HTTP " + code + (err != null && !err.isEmpty() ? "：" + trimErr(err) : ""));
        }
        String resp = read(c.getInputStream());
        JSONObject j = new JSONObject(resp);
        JSONArray choices = j.optJSONArray("choices");
        if (choices == null || choices.length() == 0) throw new Exception(App.ctx().getString(R.string.ai_err_empty));
        return choices.optJSONObject(0).optJSONObject("message").optString("content");
    }

    public static String test(JSONObject st) {
        String base = resolveBase(st, com.mc.cmd.assistant.data.DataStore.get().providers);
        if (base.isEmpty()) return App.ctx().getString(R.string.ai_err_base);
        String key = st.optString("apiKey");
        if (key == null || key.isEmpty()) return App.ctx().getString(R.string.ai_err_key);
        try {
            JSONArray msgs = new JSONArray();
            JSONObject m = new JSONObject();
            m.put("role", "user");
            m.put("content", "ping");
            msgs.put(m);
            JSONObject b = new JSONObject();
            b.put("model", st.optString("model", "deepseek-chat"));
            b.put("messages", msgs);
            b.put("max_tokens", 5);
            HttpURLConnection c = open(base, st, b.toString());
            int code = c.getResponseCode();
            if (code != 200) {
                String err = read(c.getErrorStream());
                return App.ctx().getString(R.string.ai_err_http, code, err != null && !err.isEmpty() ? trimErr(err) : "");
            }
            String resp = read(c.getInputStream());
            JSONObject j = new JSONObject(resp);
            String content = j.optJSONArray("choices").optJSONObject(0).optJSONObject("message").optString("content");
            return App.ctx().getString(R.string.ai_err_ok, content == null || content.isEmpty() ? App.ctx().getString(R.string.ai_err_empty_reply) : content.trim().length() > 30 ? content.trim().substring(0, 30) : content.trim());
        } catch (Exception e) {
            return App.ctx().getString(R.string.ai_err_conn, e.getMessage());
        }
    }

    private static String read(InputStream is) throws Exception {
        if (is == null) return "";
        BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        return sb.toString();
    }

    private static String trimErr(String s) {
        try {
            JSONObject j = new JSONObject(s);
            JSONObject e = j.optJSONObject("error");
            if (e != null) return e.optString("message", s);
            if (j.has("message")) return j.optString("message");
        } catch (Exception ignored) {}
        return s.length() > 200 ? s.substring(0, 200) : s;
    }
}
