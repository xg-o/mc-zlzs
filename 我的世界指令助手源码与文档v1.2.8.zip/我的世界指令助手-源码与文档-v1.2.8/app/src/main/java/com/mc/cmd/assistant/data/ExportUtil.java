package com.mc.cmd.assistant.data;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** 数据导出/导入：全部 / 收藏 / 聊天 / API 信息，支持 ZIP */
public class ExportUtil {

    public static final int EXPORT_ALL = 0;
    public static final int EXPORT_FAVS = 1;
    public static final int EXPORT_CHAT = 2;
    public static final int EXPORT_API = 3;

    /** 导出到 cache/export/ 返回文件 */
    public static File export(Context c, int type) throws Exception {
        Prefs p = new Prefs(c);
        File dir = new File(c.getCacheDir(), "export");
        if (!dir.exists()) dir.mkdirs();
        JSONObject root = new JSONObject();
        root.put("app", "mc-cmd-assistant");
        root.put("version", "1.1.0");
        root.put("type", type == EXPORT_ALL ? "all" : type == EXPORT_FAVS ? "favorites" : type == EXPORT_CHAT ? "chat" : "api");
        if (type == EXPORT_ALL || type == EXPORT_FAVS) {
            root.put("favorites", p.getFavs());
        }
        if (type == EXPORT_ALL || type == EXPORT_CHAT) {
            root.put("conversations", p.getConvs());
            root.put("aiSaved", p.getAiSaved());
        }
        if (type == EXPORT_ALL || type == EXPORT_API) {
            root.put("settings", p.getSettings());
            root.put("apiPort", p.getApiPort());
        }
        if (type == EXPORT_ALL) {
            root.put("lastCmds", new JSONArray(p.getLastCmds()));
        }
        String name = type == EXPORT_FAVS ? "favorites" : type == EXPORT_CHAT ? "chat" : type == EXPORT_API ? "api" : "all";
        File f = new File(dir, "mc-assistant-" + name + ".json");
        FileOutputStream fos = new FileOutputStream(f);
        fos.write(root.toString(1).getBytes(StandardCharsets.UTF_8));
        fos.close();
        return f;
    }

    /** 导出 ZIP（全部数据拆分子项打包） */
    public static File exportZip(Context c) throws Exception {
        Prefs p = new Prefs(c);
        File dir = new File(c.getCacheDir(), "export");
        if (!dir.exists()) dir.mkdirs();
        File zip = new File(dir, "mc-assistant-backup.zip");
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip));

        String[][] files = {
                {"all.json", export(c, EXPORT_ALL).getAbsolutePath()},
                {"favorites.json", export(c, EXPORT_FAVS).getAbsolutePath()},
                {"chat.json", export(c, EXPORT_CHAT).getAbsolutePath()},
                {"api.json", export(c, EXPORT_API).getAbsolutePath()},
                {"readme.txt", null},
        };
        for (String[] item : files) {
            zos.putNextEntry(new ZipEntry(item[0]));
            if (item[1] == null) {
                zos.write("Minecraft Command Assistant backup\n导出时间: \n包含: favorites.json / chat.json / api.json / all.json\n".getBytes(StandardCharsets.UTF_8));
            } else {
                FileInputStream fis = new FileInputStream(item[1]);
                byte[] buf = new byte[8192];
                int n;
                while ((n = fis.read(buf)) > 0) zos.write(buf, 0, n);
                fis.close();
            }
            zos.closeEntry();
        }
        zos.close();
        return zip;
    }

    /** 解析导入文件：支持单 JSON 或 ZIP（内含分项）。返回 {favorites?, conversations?, aiSaved?, settings?, apiPort?} */
    public static JSONObject parseImport(File f) throws Exception {
        String name = f.getName().toLowerCase();
        if (name.endsWith(".zip")) {
            JSONObject merged = new JSONObject();
            ZipInputStream zis = new ZipInputStream(new FileInputStream(f));
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                if (!e.getName().endsWith(".json")) { zis.closeEntry(); continue; }
                byte[] buf = new byte[(int) e.getSize() > 0 ? (int) e.getSize() : 65536];
                int off = 0, n;
                while (off < buf.length && (n = zis.read(buf, off, buf.length - off)) > 0) off += n;
                zis.closeEntry();
                try {
                    JSONObject j = new JSONObject(new String(buf, 0, off, StandardCharsets.UTF_8));
                    mergeInto(merged, j);
                } catch (Exception ignored) {}
            }
            zis.close();
            return merged;
        }
        return new JSONObject(readAll(f));
    }

    private static void mergeInto(JSONObject dst, JSONObject src) throws Exception {
        String[] keys = {"favorites", "conversations", "aiSaved", "settings", "lastCmds"};
        for (String k : keys) {
            if (src.has(k)) {
                if (dst.has(k) && dst.opt(k) instanceof JSONArray && src.opt(k) instanceof JSONArray) {
                    JSONArray a = dst.optJSONArray(k);
                    JSONArray b = src.optJSONArray(k);
                    JSONArray na = new JSONArray();
                    for (int i = 0; i < a.length(); i++) na.put(a.opt(i));
                    for (int i = 0; i < b.length(); i++) {
                        JSONObject o = b.optJSONObject(i);
                        boolean dup = false;
                        for (int j = 0; j < na.length(); j++) {
                            JSONObject x = na.optJSONObject(j);
                            if (x != null && o != null && x.toString().equals(o.toString())) { dup = true; break; }
                        }
                        if (!dup) na.put(o);
                    }
                    dst.put(k, na);
                } else {
                    dst.put(k, src.opt(k));
                }
            }
        }
        if (src.has("apiPort")) dst.put("apiPort", src.opt("apiPort"));
    }

    /** 应用导入内容：flags 按位 favorites=1, chat=2, api=4 */
    public static int applyImport(Context c, JSONObject data, int flags) {
        Prefs p = new Prefs(c);
        int n = 0;
        try {
            if ((flags & 1) != 0 && data.has("favorites")) { p.set(Prefs.KEY_FAVS, data.optJSONArray("favorites").toString()); n++; }
            if ((flags & 2) != 0) {
                if (data.has("conversations")) { p.set(Prefs.KEY_CONVS, data.optJSONArray("conversations").toString()); n++; }
                if (data.has("aiSaved")) { p.set(Prefs.KEY_AI_SAVED, data.optJSONArray("aiSaved").toString()); n++; }
            }
            if ((flags & 4) != 0) {
                if (data.has("settings")) { p.set(Prefs.KEY_SETTINGS, data.optJSONObject("settings").toString()); n++; }
                if (data.has("apiPort")) p.setApiPort(data.optInt("apiPort", 8756));
            }
        } catch (Exception ignored) {}
        return n;
    }

    private static String readAll(File f) throws Exception {
        byte[] buf = new byte[(int) f.length()];
        FileInputStream fis = new FileInputStream(f);
        int off = 0, n;
        while (off < buf.length && (n = fis.read(buf, off, buf.length - off)) > 0) off += n;
        fis.close();
        return new String(buf, 0, off, StandardCharsets.UTF_8);
    }
}
