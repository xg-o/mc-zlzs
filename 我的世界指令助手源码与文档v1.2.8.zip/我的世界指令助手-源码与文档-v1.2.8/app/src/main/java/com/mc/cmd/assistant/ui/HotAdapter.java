package com.mc.cmd.assistant.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Models.Preset;
import com.mc.cmd.assistant.data.Prefs;

import java.util.List;

public class HotAdapter extends RecyclerView.Adapter<HotAdapter.VH> {
    private final List<Preset> items;

    public HotAdapter(List<Preset> items) { this.items = items; }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_preset, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Preset p = items.get(pos);
        h.cmd.setText(p.cmd);
        h.desc.setText(p.d);
        Prefs pv = new Prefs(h.itemView.getContext());
        if ("命令源".equals(p.c)) {
            h.compat.setText(R.string.src_compat_hint);
        } else {
            String line = h.itemView.getContext().getString(R.string.compat_line, Preset.VER_BEDROCK);
            String uv = pv.getMcVersion();
            if (uv != null && !uv.isEmpty()) {
                line += " · " + (Preset.inRange(uv)
                        ? h.itemView.getContext().getString(R.string.compat_ok, uv)
                        : h.itemView.getContext().getString(R.string.compat_bad, uv));
            }
            h.compat.setText(line);
        }
        Prefs prefs = new Prefs(h.itemView.getContext());
        String ref = "hot|" + p.cmd;
        h.star.setOnClickListener(x -> {
            boolean on = prefs.toggleFav("preset", ref, p.c, p.cmd, p.d);
            DataStore.get(); // keep ref
            h.star.setImageResource(on ? R.drawable.ic_star_filled : R.drawable.ic_star);
            Toast.makeText(h.itemView.getContext(), on ? R.string.fav_added : R.string.fav_removed, Toast.LENGTH_SHORT).show();
        });
        h.star.setImageResource(prefs.isFav("preset", ref) ? R.drawable.ic_star_filled : R.drawable.ic_star);
        h.itemView.setOnClickListener(x -> Clip.copy(h.itemView.getContext(), p.cmd));
        h.copy.setOnClickListener(x -> Clip.copy(h.itemView.getContext(), p.cmd));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView cmd, desc, compat;
        ImageButton copy, star;

        VH(@NonNull View v) {
            super(v);
            cmd = v.findViewById(R.id.itemCmd);
            desc = v.findViewById(R.id.itemDesc);
            compat = v.findViewById(R.id.itemCompat);
            copy = v.findViewById(R.id.itemCopy);
            star = v.findViewById(R.id.itemStar);
        }
    }
}
