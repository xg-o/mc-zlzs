package com.mc.cmd.assistant.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.mc.cmd.assistant.BaseActivity;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Models;
import com.mc.cmd.assistant.data.Models.Preset;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.data.RunLog;
import com.mc.cmd.assistant.data.SourceFetcher;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** 命令源管理：添加链接自动获取指令，支持开启/关闭、详情、删除 */
public class SourcesActivity extends BaseActivity {

    private Prefs prefs;
    private final List<Object> items = new ArrayList<>();
    private SourceAdapter adapter;
    private TextView empty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sources);
        prefs = new Prefs(this);
        ((MaterialToolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(x -> finish());
        ((MaterialToolbar) findViewById(R.id.toolbar)).setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_restore_builtin) {
                prefs.restoreBuiltin();
                RunLog.log(this, RunLog.T_SOURCE, "重新添加内置命令库");
                refresh();
                Toast.makeText(this, R.string.src_builtin_restored, Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });

        RecyclerView rv = findViewById(R.id.srcList);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SourceAdapter();
        rv.setAdapter(adapter);

        empty = findViewById(R.id.srcEmpty);
        findViewById(R.id.srcAdd).setOnClickListener(x -> addDialog());
        refresh();
    }

    private void refresh() {
        items.clear();
        // 固定首位：内置命令库
        JSONObject builtin = new JSONObject();
        try {
            builtin.put("id", "builtin");
            builtin.put("name", getString(R.string.builtin_source_name));
            builtin.put("url", getString(R.string.builtin_source_url));
            builtin.put("enabled", prefs.getBuiltinEnabled());
            builtin.put("ts", 0L);
            builtin.put("cmds", new JSONArray());
        } catch (Exception ignored) {}
        if (!prefs.getBuiltinDeleted()) items.add(builtin);
        // 三类源分组：拼接 / 预设 / ID
        addGroup(R.string.src_group_template, "template");
        addGroup(R.string.src_group_preset, "preset");
        addGroup(R.string.src_group_id, "id");
        adapter.notifyDataSetChanged();
        int dataCount = 0;
        for (Object x : items) if (x instanceof JSONObject && !isBuiltin((JSONObject) x)) dataCount++;
        empty.setVisibility(dataCount == 0 ? View.VISIBLE : View.GONE);
    }

    private void addGroup(int titleRes, String type) {
        JSONArray a = prefs.getSources();
        List<JSONObject> g = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && type.equals(o.optString("type", "preset"))) g.add(o);
        }
        items.add(getString(titleRes));
        if (g.isEmpty()) {
            items.add(getString(R.string.src_group_empty));
            return;
        }
        items.addAll(g);
    }

    private boolean isBuiltin(JSONObject o) { return "builtin".equals(o.optString("id")); }

    private void addDialog() {
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        ll.setPadding(pad, dp(6), pad, 0);
        String[][] rows = {
                {getString(R.string.src_group_template), "template"},
                {getString(R.string.src_group_preset), "preset"},
                {getString(R.string.src_group_id), "id"}};
        for (String[] r : rows) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            TextView label = new TextView(this);
            label.setText(r[0]);
            label.setTextSize(13f);
            label.setTextColor(0xFF6750A4);
            label.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            label.setPadding(0, 0, dp(8), 0);
            row.addView(label, new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
            EditText url = new EditText(this);
            url.setHint(R.string.src_url_hint);
            url.setSingleLine(true);
            url.setTextSize(13f);
            url.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
            row.addView(url, new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            Button add = new Button(this);
            add.setText(R.string.src_add);
            add.setTextSize(12f);
            add.setTextColor(0xFFFFFFFF);
            add.setBackgroundResource(R.drawable.bg_float_btn);
            add.setMinHeight(dp(34));
            row.addView(add);
            ll.addView(row);
            final String type = r[1];
            add.setOnClickListener(x -> fetchAndAdd(url.getText() == null ? "" : url.getText().toString().trim(), type));
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.src_add)
                .setView(ll)
                .setPositiveButton(R.string.close, null)
                .show();
    }

    private void fetchAndAdd(final String u, final String hintType) {
        if (u.isEmpty()) { Toast.makeText(this, R.string.src_url_empty, Toast.LENGTH_SHORT).show(); return; }
        Toast.makeText(this, R.string.src_fetching, Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                SourceFetcher.Result r = SourceFetcher.fetch(u);
                runOnUiThread(() -> {
                    if (r.count() == 0) {
                        Toast.makeText(this, getString(R.string.src_fail, "empty"), Toast.LENGTH_LONG).show();
                        return;
                    }
                    saveSource(u, r.type, r);
                });
            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(this, getString(R.string.src_fail, e.getMessage()), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void saveSource(String u, String type, SourceFetcher.Result r) {
        try {
            JSONObject o = new JSONObject();
            o.put("id", UUID.randomUUID().toString());
            o.put("name", hostOf(u));
            o.put("url", u);
            o.put("enabled", true);
            o.put("ts", System.currentTimeMillis());
            o.put("type", type);
            JSONArray ca = new JSONArray();
            for (Preset p : r.presets) {
                JSONObject c = new JSONObject();
                c.put("cmd", p.cmd);
                c.put("d", p.d == null ? "" : p.d);
                ca.put(c);
            }
            for (Models.Template t : r.templates) {
                JSONObject c = new JSONObject();
                c.put("n", t.n);
                c.put("s", t.s);
                ca.put(c);
            }
            for (Models.IdEntry e : r.ids) {
                JSONObject c = new JSONObject();
                c.put("id", e.id);
                c.put("n", e.name == null ? "" : e.name);
                c.put("note", e.note == null ? "" : e.note);
                ca.put(c);
            }
            o.put("cmds", ca);
            JSONArray na = prefs.getSources();
            JSONArray all = new JSONArray();
            all.put(o);
            for (int i = 0; i < na.length(); i++) all.put(na.opt(i));
            prefs.saveSources(all);
            RunLog.log(this, RunLog.T_SOURCE, "添加" + typeLabel(type) + "源 " + u + "，共 " + r.count() + " 条");
            refresh();
            Toast.makeText(this, getString(R.string.src_ok_type, typeLabel(type), r.count()), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.src_fail, e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private String hostOf(String url) {
        try { return URI.create(url).getHost(); } catch (Exception e) { return getString(R.string.src_unknown); }
    }

    private String typeLabel(String type) {
        if ("template".equals(type)) return getString(R.string.src_type_template);
        if ("id".equals(type)) return getString(R.string.src_type_id);
        return getString(R.string.src_type_preset);
    }

    private void showDetail(JSONObject o) {
        String name = o.optString("name");
        String url = o.optString("url");
        String type = o.optString("type", "preset");
        JSONArray cmds = o.optJSONArray("cmds");
        int n = cmds == null ? 0 : cmds.length();
        List<String> lines = new ArrayList<>();
        int max = Math.min(200, n);
        for (int i = 0; i < max; i++) {
            JSONObject c = cmds.optJSONObject(i);
            if (c == null) continue;
            if ("template".equals(type)) {
                String ts = c.optString("s");
                if (ts.isEmpty()) ts = c.optString("template");
                lines.add(c.optString("n") + "  " + ts);
            } else if ("id".equals(type)) {
                lines.add(c.optString("id") + "  " + c.optString("n"));
            } else {
                lines.add(c.optString("cmd"));
            }
        }
        if (lines.size() < n) lines.add("… " + (n - max) + " …");
        String[] arr = lines.toArray(new String[0]);

        FrameLayout wrap = new FrameLayout(this);
        int pad = dp(16);
        wrap.setPadding(pad, pad / 2, pad, 0);
        TextView info = new TextView(this);
        info.setText(getString(R.string.src_detail_info, url, n));
        info.setTextSize(12f);
        info.setTextColor(0xFF666666);
        wrap.addView(info);

        new AlertDialog.Builder(this)
                .setTitle(name)
                .setView(wrap)
                .setItems(arr, (d, w) -> Clip.copy(this, arr[w]))
                .setPositiveButton(R.string.close, null)
                .show();
    }

    private void deleteDialog(JSONObject o) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.src_delete)
                .setMessage(R.string.src_delete_confirm)
                .setPositiveButton(R.string.ok, (d, w) -> {
                    String id = o.optString("id");
                    JSONArray na = new JSONArray();
                    for (int i = 0; i < prefs.getSources().length(); i++) {
                        JSONObject x = prefs.getSources().optJSONObject(i);
                        if (x == null || !id.equals(x.optString("id"))) na.put(x);
                    }
                    prefs.saveSources(na);
                    RunLog.log(this, RunLog.T_SOURCE, "删除源 " + o.optString("name"));
                    refresh();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    class SourceAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int T_HEADER = 0, T_ITEM = 1;

        @Override
        public int getItemViewType(int pos) {
            return items.get(pos) instanceof String ? T_HEADER : T_ITEM;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            if (viewType == T_HEADER) {
                return new RecyclerView.ViewHolder(
                        LayoutInflater.from(parent.getContext()).inflate(R.layout.item_source_header, parent, false)) {};
            }
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_source, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder hh, int pos) {
            Object item = items.get(pos);
            if (item instanceof String) {
                TextView tv = (TextView) hh.itemView;
                tv.setText((String) item);
                tv.setTextColor(getString(R.string.src_group_empty).equals(item)
                        ? 0xFF999999 : 0xFF6750A4);
                tv.setTextSize(getString(R.string.src_group_empty).equals(item) ? 12f : 13f);
                return;
            }
            JSONObject o = (JSONObject) item;
            VH h = (VH) hh;
            if (isBuiltin(o)) {
                h.name.setText(o.optString("name"));
                h.url.setText(o.optString("url"));
                h.count.setText(getString(R.string.src_count, DataStore.get().presets.size()));
                h.status.setText(R.string.src_builtin);
                h.status.setBackgroundResource(R.drawable.bg_tag);
                boolean on = prefs.getBuiltinEnabled();
                h.sw.setChecked(on);
                h.sw.setOnCheckedChangeListener((b, is) -> {
                    prefs.setBuiltinEnabled(is);
                    RunLog.log(SourcesActivity.this, RunLog.T_SOURCE, (is ? "开启" : "关闭") + "内置命令库");
                    refresh();
                });
                h.detail.setOnClickListener(x ->
                        new AlertDialog.Builder(SourcesActivity.this)
                                .setTitle(R.string.builtin_source_name)
                                .setMessage(getString(R.string.src_builtin_note, DataStore.get().presets.size()))
                                .setPositiveButton(R.string.close, null)
                                .show());
                h.delete.setOnClickListener(x ->
                        new AlertDialog.Builder(SourcesActivity.this)
                                .setTitle(R.string.builtin_source_name)
                                .setMessage(R.string.src_builtin_delete_confirm)
                                .setPositiveButton(R.string.src_delete, (d, w) -> {
                                    prefs.setBuiltinDeleted(true);
                                    RunLog.log(SourcesActivity.this, RunLog.T_SOURCE, "删除内置命令库");
                                    refresh();
                                })
                                .setNegativeButton(R.string.cancel, null)
                                .show());
                h.itemView.setOnClickListener(null);
                return;
            }
            boolean on = o.optBoolean("enabled", true);
            h.name.setText(o.optString("name"));
            h.url.setText(o.optString("url"));
            JSONArray cmds = o.optJSONArray("cmds");
            h.count.setText(getString(R.string.src_count_type, cmds == null ? 0 : cmds.length(), typeLabel(o.optString("type", "preset"))));
            h.status.setText(on ? R.string.src_enabled : R.string.src_disabled);
            h.status.setBackgroundResource(on ? R.drawable.bg_tag : R.drawable.bg_tag_warn);
            h.sw.setChecked(on);
            h.sw.setOnCheckedChangeListener((b, is) -> {
                try {
                    o.put("enabled", is);
                    JSONArray na = new JSONArray();
                    for (Object x : items) if (x instanceof JSONObject && !isBuiltin((JSONObject) x)) na.put(x);
                    prefs.saveSources(na);
                    RunLog.log(SourcesActivity.this, RunLog.T_SOURCE, (is ? "开启" : "关闭") + "源 " + o.optString("name"));
                    refresh();
                } catch (Exception ignored) {}
            });
            h.detail.setOnClickListener(x -> showDetail(o));
            h.delete.setOnClickListener(x -> deleteDialog(o));
            h.itemView.setOnClickListener(x -> showDetail(o));
        }

        @Override
        public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView name, url, count, status;
            SwitchMaterial sw;
            ImageButton detail, delete;

            VH(@NonNull View v) {
                super(v);
                name = v.findViewById(R.id.srcName);
                url = v.findViewById(R.id.srcUrl);
                count = v.findViewById(R.id.srcCount);
                status = v.findViewById(R.id.srcStatus);
                sw = v.findViewById(R.id.srcSwitch);
                detail = v.findViewById(R.id.srcDetail);
                delete = v.findViewById(R.id.srcDelete);
            }
        }
    }
}
