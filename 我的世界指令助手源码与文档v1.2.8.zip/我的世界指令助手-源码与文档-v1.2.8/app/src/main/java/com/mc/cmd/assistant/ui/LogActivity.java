package com.mc.cmd.assistant.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.mc.cmd.assistant.BaseActivity;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.RunLog;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** 运行日志：复制 / API / 悬浮窗 / 崩溃等事件 */
public class LogActivity extends BaseActivity {

    private final List<JSONObject> items = new ArrayList<>();
    private LogAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);
        MaterialToolbar tb = findViewById(R.id.toolbar);
        tb.setNavigationOnClickListener(x -> finish());
        tb.inflateMenu(R.menu.menu_log);

        RecyclerView rv = findViewById(R.id.logList);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new LogAdapter();
        rv.setAdapter(adapter);
        refresh();

        tb.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.action_log_clear) {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.log_clear)
                        .setMessage(R.string.log_clear_confirm)
                        .setPositiveButton(R.string.ok, (d, w) -> {
                            RunLog.clear(this);
                            refresh();
                            Toast.makeText(this, R.string.log_cleared, Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
                return true;
            }
            if (id == R.id.action_log_export) {
                export();
                return true;
            }
            return false;
        });
    }

    private void refresh() {
        items.clear();
        items.addAll(RunLog.entries(this));
        adapter.notifyDataSetChanged();
        findViewById(R.id.logEmpty).setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void export() {
        try {
            File dir = new File(getCacheDir(), "export");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "run-log.json");
            JSONObject root = new JSONObject();
            root.put("app", "mc-cmd-assistant");
            root.put("export", "runlog");
            root.put("entries", RunLog.toJson(this));
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(root.toString(1).getBytes(StandardCharsets.UTF_8));
            fos.close();
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, getString(R.string.log_export)));
            Toast.makeText(this, R.string.log_exported, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.src_fail, e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private static final SimpleDateFormat SDF = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault());

    class LogAdapter extends RecyclerView.Adapter<LogAdapter.VH> {
        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_log, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            JSONObject o = items.get(pos);
            String type = o.optString("type");
            h.time.setText(SDF.format(new Date(o.optLong("ts"))));
            h.type.setText(RunLog.typeRes(type));
            if (RunLog.T_CRASH.equals(type)) h.type.setBackgroundResource(R.drawable.bg_tag_bad);
            else if (RunLog.T_FLOAT.equals(type) || RunLog.T_API.equals(type)) h.type.setBackgroundResource(R.drawable.bg_tag_warn);
            else h.type.setBackgroundResource(R.drawable.bg_tag);
            h.msg.setText(o.optString("msg"));
        }

        @Override
        public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView time, type, msg;
            VH(@NonNull View v) {
                super(v);
                time = v.findViewById(R.id.logTime);
                type = v.findViewById(R.id.logType);
                msg = v.findViewById(R.id.logMsg);
            }
        }
    }
}
