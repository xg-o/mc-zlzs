package com.mc.cmd.assistant.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.mc.cmd.assistant.MainActivity;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.ai.AiActivity;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Models.Preset;
import com.mc.cmd.assistant.data.Prefs;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);

        DataStore ds = DataStore.get();
        ((android.widget.TextView) v.findViewById(R.id.statPresetNum)).setText(String.valueOf(ds.presets.size()));
        ((android.widget.TextView) v.findViewById(R.id.statIdNum)).setText(String.valueOf(ds.idTotal()));
        ((android.widget.TextView) v.findViewById(R.id.statTplNum)).setText(String.valueOf(ds.templates.size()));

        v.findViewById(R.id.searchBar).setOnClickListener(x -> startActivity(new Intent(getContext(), SearchActivity.class)));
        v.findViewById(R.id.aiCard).setOnClickListener(x -> startActivity(new Intent(getContext(), AiActivity.class)));
        v.findViewById(R.id.quickAi).setOnClickListener(x -> startActivity(new Intent(getContext(), AiActivity.class)));
        v.findViewById(R.id.quickBuilder).setOnClickListener(x -> selectTab(R.id.nav_builder));
        v.findViewById(R.id.quickPreset).setOnClickListener(x -> selectTab(R.id.nav_preset));
        v.findViewById(R.id.quickIds).setOnClickListener(x -> selectTab(R.id.nav_ids));

        RecyclerView rv = v.findViewById(R.id.hotList);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        List<Preset> hot = new ArrayList<>();
        String[][] common = {
                {"/give @s command_block", "获取命令方块，可执行红石信号"},
                {"/weather clear", "设置晴天"},
                {"/time set day", "设置白天"},
                {"/kill @e[type=item]", "清理地面掉落物"},
                {"/gamemode creative @s", "切换到创造模式"},
                {"/effect @s night_vision 1000000 0 true", "永久夜视"},
                {"/effect @s resistance 1000000 255 true", "永久抗性，近乎无敌"},
                {"/tp @s 0 100 0", "传送回世界原点"}
        };
        for (String[] c : common) hot.add(new Preset("常用", c[0], c[1]));
        rv.setAdapter(new HotAdapter(hot));
        return v;
    }

    private void selectTab(int id) {
        MainActivity a = (MainActivity) requireActivity();
        BottomNavigationView nav = a.findViewById(R.id.nav);
        nav.setSelectedItemId(id);
    }
}
