package com.mc.cmd.assistant.ui;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.format.Formatter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.mc.cmd.assistant.BaseActivity;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.api.HttpApiService;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.data.RunLog;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

/** 关于：关于 / 更新日志 / 开发者文档（本地 API 服务）/ 使用教程 */
public class AboutActivity extends BaseActivity {

    private Prefs prefs;
    private TextView apiStatus, apiAddrs;
    private TextInputEditText apiPort;
    private MaterialButton apiToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        prefs = new Prefs(this);
        ((MaterialToolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(x -> finish());

        apiStatus = findViewById(R.id.apiStatus);
        apiAddrs = findViewById(R.id.apiAddrs);
        apiPort = findViewById(R.id.apiPort);
        apiToggle = findViewById(R.id.apiToggle);
        apiPort.setText(String.valueOf(prefs.getApiPort()));

        apiToggle.setOnClickListener(x -> {
            if (HttpApiService.isRunning()) {
                try {
                    stopService(new Intent(this, HttpApiService.class));
                } catch (Exception e) {
                    RunLog.log(this, RunLog.T_API, e);
                }
                refresh();
            } else {
                int port;
                try {
                    port = Integer.parseInt(apiPort.getText() == null ? "" : apiPort.getText().toString().trim());
                } catch (Exception e) { port = 0; }
                if (port < 1024 || port > 65535) {
                    Toast.makeText(this, R.string.dev_api_port_invalid, Toast.LENGTH_LONG).show();
                    return;
                }
                prefs.setApiPort(port);
                try {
                    startForegroundService(new Intent(this, HttpApiService.class));
                } catch (Exception e) {
                    RunLog.log(this, RunLog.T_API, e);
                    Toast.makeText(this, getString(R.string.dev_api_start_fail, e.getMessage()), Toast.LENGTH_LONG).show();
                }
                refresh();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean on = HttpApiService.isRunning();
        apiStatus.setText(on ? R.string.dev_api_running : R.string.dev_api_stopped);
        apiToggle.setText(on ? R.string.dev_api_stop : R.string.dev_api_start);
        if (on) {
            int port = prefs.getApiPort();
            String local = "http://127.0.0.1:" + port;
            String localhost = "http://localhost:" + port;
            String lan = getLanIp();
            StringBuilder sb = new StringBuilder();
            sb.append(getString(R.string.dev_api_addr_local, local)).append('\n');
            sb.append(getString(R.string.dev_api_addr_localhost, localhost)).append('\n');
            if (lan != null) sb.append(getString(R.string.dev_api_addr_lan, "http://" + lan + ":" + port));
            else sb.append(getString(R.string.dev_api_no_wifi));
            apiAddrs.setText(sb.toString());
            apiAddrs.setVisibility(TextView.VISIBLE);
        } else {
            apiAddrs.setVisibility(TextView.GONE);
        }
    }

    private String getLanIp() {
        try {
            List<NetworkInterface> nis = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface ni : nis) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address) {
                        String ip = a.getHostAddress();
                        if (ip != null && ip.startsWith("192.") || ip != null && ip.startsWith("10.") || ip != null && ip.startsWith("172.")) {
                            return ip;
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }
}
