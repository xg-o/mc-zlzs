package com.mc.cmd.assistant.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 轻量数据模型：预设命令 / 拼接模板 / ID 条目 */
public class Models {

    public static class Preset {
        /** 兼容版本范围（基岩版） */
        public static final String VER_BEDROCK = "1.26.43.1～1.26.45.1";
        public String c;   // 分类
        public String cmd; // 命令
        public String d;   // 简介
        public String t;   // 测试标签 已测试/未测试/注意
        public Preset(JSONObject o) {
            c = o.optString("c");
            cmd = o.optString("cmd");
            d = o.optString("d");
            t = o.optString("t");
        }
        public String tagText() { return t == null || t.isEmpty() ? "已测试" : t; }
        public boolean isTested() { return t == null || t.isEmpty() || "已测试".equals(t); }
        /** 兼容版本范围（基岩版） */
        public static final String VER_MIN = "1.26.43.1";
        public static final String VER_MAX = "1.26.45.1";

        public Preset(String c, String cmd, String d) {
            this.c = c; this.cmd = cmd; this.d = d; this.t = "";
        }

        /** 判断用户的基岩版版本是否在兼容范围内 */
        public static boolean inRange(String v) {
            if (v == null || v.trim().isEmpty()) return true;
            String s = v.trim().replaceAll("[^0-9.]", "");
            if (s.isEmpty()) return true;
            return cmp(s, VER_MIN) >= 0 && cmp(s, VER_MAX) <= 0;
        }

        private static int cmp(String a, String b) {
            String[] pa = a.split("\\.");
            String[] pb = b.split("\\.");
            int n = Math.max(pa.length, pb.length);
            for (int i = 0; i < n; i++) {
                int x = i < pa.length ? parseInt(pa[i]) : 0;
                int y = i < pb.length ? parseInt(pb[i]) : 0;
                if (x != y) return Integer.compare(x, y);
            }
            return 0;
        }

        private static int parseInt(String s) {
            try { return Integer.parseInt(s); } catch (Exception e) { return 0; }
        }
    }

    public static class Arg {
        public String k, l, t, d, h, sugPool;
        public boolean opt;
        public List<String> o = new ArrayList<>();
        public List<String> sug = new ArrayList<>();
        public Arg(JSONObject a) {
            k = a.optString("k");
            l = a.optString("l");
            t = a.optString("t");
            d = a.optString("d");
            h = a.optString("h");
            opt = a.optBoolean("opt");
            JSONArray oa = a.optJSONArray("o");
            if (oa != null) for (int i = 0; i < oa.length(); i++) o.add(oa.optString(i));
            JSONArray sa = a.optJSONArray("sug");
            if (sa != null) for (int i = 0; i < sa.length(); i++) sug.add(sa.optString(i));
            else if (a.has("sug")) sugPool = a.optString("sug");
        }
    }

    public static class Template {
        public String id, n, s;
        public List<String> cmd = new ArrayList<>();
        public List<Arg> args = new ArrayList<>();
        public Template(JSONObject o) {
            id = o.optString("id");
            n = o.optString("n");
            s = o.optString("s");
            Object c = o.opt("cmd");
            if (c instanceof JSONArray) {
                JSONArray ca = (JSONArray) c;
                for (int i = 0; i < ca.length(); i++) cmd.add(ca.optString(i));
            } else if (c != null) {
                cmd.add(String.valueOf(c));
            } else {
                cmd.add(id);
            }
            JSONArray aa = o.optJSONArray("args");
            if (aa != null) for (int i = 0; i < aa.length(); i++) args.add(new Arg(aa.optJSONObject(i)));
        }
    }

    public static class IdEntry {
        public String cat;
        public String id;
        public String name;
        public String note;
        public IdEntry(String cat, String id, String name, String note) {
            this.cat = cat; this.id = id; this.name = name; this.note = note;
        }
    }

    public static class Provider {
        public String id, name, base, note;
        public boolean custom;
        public List<String> models = new ArrayList<>();
        public Provider(JSONObject o) {
            id = o.optString("id");
            name = o.optString("name");
            base = o.optString("base");
            note = o.optString("note");
            custom = o.optBoolean("custom");
            JSONArray ma = o.optJSONArray("models");
            if (ma != null) for (int i = 0; i < ma.length(); i++) models.add(ma.optString(i));
        }
    }

    public static class SearchResult {
        public List<Preset> presets = new ArrayList<>();
        public List<Template> templates = new ArrayList<>();
        public List<IdEntry> ids = new ArrayList<>();
        public boolean isEmpty() { return presets.isEmpty() && templates.isEmpty() && ids.isEmpty(); }
        public int total() { return presets.size() + templates.size() + ids.size(); }
    }
}
