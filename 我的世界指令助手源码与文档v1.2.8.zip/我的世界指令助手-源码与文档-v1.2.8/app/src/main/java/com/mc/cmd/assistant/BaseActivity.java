package com.mc.cmd.assistant;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.color.DynamicColors;
import com.google.android.material.color.DynamicColorsOptions;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.util.LangUtil;
import com.mc.cmd.assistant.util.ThemeUtil;

/** 所有 Activity 基类：语言 + 主题 */
public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LangUtil.wrap(newBase));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        String theme = new Prefs(this).getTheme();
        if (!ThemeUtil.isCustom(theme)) {
            setTheme(ThemeUtil.styleRes(theme));
        }
        super.onCreate(savedInstanceState);
        if (ThemeUtil.isCustom(theme) && Build.VERSION.SDK_INT >= 31) {
            int c = ThemeUtil.customColor(this);
            if (c != 0) {
                DynamicColorsOptions opts = new DynamicColorsOptions.Builder()
                        .setContentBasedSource(c)
                        .build();
                DynamicColors.applyToActivityIfAvailable(this, opts);
            }
        }
    }
}
