package com.mc.cmd.assistant.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.data.Models.IdEntry;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class IdsFragment extends Fragment {

    private String cat = "blocks";
    private final List<Chip> catChips = new ArrayList<>();
    private IdsAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_ids, container, false);
        buildCats(v);

        TextInputEditText search = v.findViewById(R.id.idSearch);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { refresh(v); }
        });

        RecyclerView rv = v.findViewById(R.id.idList);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        refresh(v);
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        View v = getView();
        if (v != null) buildCats(v);
    }

    private void buildCats(View v) {
        DataStore ds = DataStore.get();
        Prefs prefs = new Prefs(requireContext());
        catChips.clear();
        ChipGroup cg = v.findViewById(R.id.idCats);
        cg.removeAllViews();
        int srcIds = prefs.srcCount("id");
        if (srcIds > 0) {
            Chip chip = new Chip(requireContext());
            chip.setText(getString(R.string.ids_source_cat) + " " + srcIds);
            chip.setCheckable(true);
            chip.setTag("__src__");
            chip.setOnClickListener(x -> {
                cat = "__src__";
                for (Chip ch : catChips) ch.setChecked(ch == chip);
                TextInputEditText si = v.findViewById(R.id.idSearch);
                si.setText("");
                refresh(v);
            });
            cg.addView(chip);
            catChips.add(chip);
        }
        if (!prefs.getBuiltinEnabled()) {
            cat = srcIds > 0 ? "__src__" : "";
            refresh(v);
            return;
        }
        boolean first = true;
        for (String[] c : ds.idCats) {
            Chip chip = new Chip(requireContext());
            chip.setText(c[1] + " " + ds.ids.getOrDefault(c[0], new ArrayList<>()).size());
            chip.setCheckable(true);
            chip.setTag(c[0]);
            chip.setOnClickListener(x -> {
                cat = (String) chip.getTag();
                for (Chip ch : catChips) ch.setChecked(ch == chip);
                TextInputEditText si = v.findViewById(R.id.idSearch);
                si.setText("");
                refresh(v);
            });
            cg.addView(chip);
            catChips.add(chip);
            if (first || "blocks".equals(c[0])) { chip.setChecked("blocks".equals(c[0])); first = false; }
        }
        if (!"__src__".equals(cat)) cat = "blocks";
        refresh(v);
    }

    private void refresh(View v) {
        DataStore ds = DataStore.get();
        TextInputEditText si = v.findViewById(R.id.idSearch);
        String q = si.getText() == null ? "" : si.getText().toString().trim().toLowerCase(Locale.ROOT);
        TextView hint = v.findViewById(R.id.idHint);
        List<IdEntry> list;
        Prefs prefs = new Prefs(requireContext());
        boolean bi = prefs.getBuiltinEnabled();
        if (q.isEmpty()) {
            if ("__src__".equals(cat)) {
                list = prefs.sourceIds();
                hint.setText(R.string.ids_source_hint);
            } else if (bi && ds.idCats != null) {
                list = ds.ids.getOrDefault(cat, new ArrayList<>());
                hint.setText(ds.idCatHints.getOrDefault(cat, ""));
            } else {
                list = new ArrayList<>();
                hint.setText(R.string.ids_source_hint);
            }
        } else {
            list = new ArrayList<>();
            if (bi) list.addAll(ds.flatIds());
            list.addAll(prefs.sourceIds());
            for (IdEntry e : list) {
                if (e.id.toLowerCase(Locale.ROOT).contains(q)
                        || (e.name != null && e.name.toLowerCase(Locale.ROOT).contains(q))
                        || (e.note != null && e.note.toLowerCase(Locale.ROOT).contains(q))) list.add(e);
            }
            hint.setText(getString(R.string.ids_cross_result, list.size()));
        }
        adapter = new IdsAdapter(list);
        RecyclerView rv = v.findViewById(R.id.idList);
        rv.setAdapter(adapter);
    }
}
