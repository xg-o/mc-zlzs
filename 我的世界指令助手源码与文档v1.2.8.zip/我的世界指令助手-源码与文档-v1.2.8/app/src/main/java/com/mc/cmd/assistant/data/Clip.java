package com.mc.cmd.assistant.data;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Toast;
import com.mc.cmd.assistant.R;

/** 复制到剪贴板 + 轻震动反馈 */
public class Clip {
    public static void copy(Context c, String text) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("mc_cmd", text));
        try {
            Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(40, 40));
        } catch (Exception ignored) {}
        Toast.makeText(c, c.getString(R.string.copy_done), Toast.LENGTH_SHORT).show();
        try {
            RunLog.log(c, RunLog.T_COPY, text.length() > 200 ? text.substring(0, 200) + "…" : text);
        } catch (Exception ignored) {}
    }
}
