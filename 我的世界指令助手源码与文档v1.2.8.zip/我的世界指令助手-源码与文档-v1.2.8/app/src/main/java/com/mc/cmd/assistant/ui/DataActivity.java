package com.mc.cmd.assistant.ui;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.card.MaterialCardView;
import com.mc.cmd.assistant.BaseActivity;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.ExportUtil;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** 数据管理：全部/部分导出（JSON/ZIP）与导入 */
public class DataActivity extends BaseActivity {

    private final ActivityResultLauncher<String[]> picker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) importFile(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);
        ((MaterialToolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(x -> finish());

        setupCard(R.id.dExportAll, R.drawable.ic_export, R.string.data_export_all, R.string.data_export_all_sub,
                () -> doExport(ExportUtil.EXPORT_ALL));
        setupCard(R.id.dExportFavs, R.drawable.ic_star, R.string.data_export_favs, R.string.data_export_favs_sub,
                () -> doExport(ExportUtil.EXPORT_FAVS));
        setupCard(R.id.dExportChat, R.drawable.ic_send, R.string.data_export_chat, R.string.data_export_chat_sub,
                () -> doExport(ExportUtil.EXPORT_CHAT));
        setupCard(R.id.dExportApi, R.drawable.ic_settings, R.string.data_export_api, R.string.data_export_api_sub,
                () -> doExport(ExportUtil.EXPORT_API));
        setupCard(R.id.dExportZip, R.drawable.ic_drag, R.string.data_export_zip, R.string.data_export_zip_sub,
                () -> doExportZip());
        setupCard(R.id.dImport, R.drawable.ic_add, R.string.data_import, R.string.data_import_sub, () -> {
            picker.launch(new String[]{"application/json", "application/zip", "application/octet-stream", "*/*"});
        });
    }

    private void setupCard(int id, int icon, int title, int sub, Runnable act) {
        MaterialCardView card = findViewById(id);
        ((ImageView) card.findViewById(R.id.entryIcon)).setImageResource(icon);
        ((TextView) card.findViewById(R.id.entryTitle)).setText(title);
        ((TextView) card.findViewById(R.id.entrySub)).setText(sub);
        card.setOnClickListener(x -> act.run());
    }

    private void doExport(int type) {
        try {
            File f = ExportUtil.export(this, type);
            share(f, "application/json");
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.data_export_fail, e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private void doExportZip() {
        try {
            File f = ExportUtil.exportZip(this);
            share(f, "application/zip");
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.data_export_fail, e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private void share(File f, String mime) {
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, getString(R.string.export_share_title)));
    }

    private void importFile(Uri uri) {
        try {
            File tmp = new File(getCacheDir(), "import_tmp");
            InputStream is = getContentResolver().openInputStream(uri);
            FileOutputStream fos = new FileOutputStream(tmp);
            byte[] buf = new byte[8192];
            int rd;
            while ((rd = is.read(buf)) > 0) fos.write(buf, 0, rd);
            is.close();
            fos.close();
            JSONObject data = ExportUtil.parseImport(tmp);
            if (data.length() == 0) {
                Toast.makeText(this, getString(R.string.data_import_fail, "empty"), Toast.LENGTH_LONG).show();
                return;
            }
            boolean[] checked = {true, true, true};
            new AlertDialog.Builder(this)
                    .setTitle(R.string.data_import_choose)
                    .setMultiChoiceItems(new String[]{
                                    getString(R.string.data_export_favs_sub),
                                    getString(R.string.data_export_chat_sub),
                                    getString(R.string.data_export_api_sub)},
                            checked, (d, w, isC) -> checked[w] = isC)
                    .setPositiveButton(R.string.ok, (d, w) -> {
                        int flags = (checked[0] ? 1 : 0) | (checked[1] ? 2 : 0) | (checked[2] ? 4 : 0);
                        if (flags == 0) { Toast.makeText(this, R.string.cancel, Toast.LENGTH_SHORT).show(); return; }
                        int n = ExportUtil.applyImport(this, data, flags);
                        Toast.makeText(this, getString(R.string.data_import_done) + " (" + n + ")", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.data_import_fail, e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }
}
