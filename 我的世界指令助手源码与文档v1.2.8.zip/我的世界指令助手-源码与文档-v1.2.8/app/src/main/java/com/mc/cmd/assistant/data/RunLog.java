package com.mc.cmd.assistant.data;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/** 运行日志：JSONL 文件，记录复制 / API / 悬浮窗 / 崩溃等事件（最多保留最近 800 条） */
public class RunLog {

    public static final String T_APP = "app";
    public static final String T_COPY = "copy";
    public static final String T_API = "api";
    public static final String T_FLOAT = "float";
    public static final String T_CRASH = "crash";
    public static final String T_SOURCE = "source";

    private static final int MAX = 800;
    private static final String NAME = "runlog.jsonl";

    private static File file(Context c) { return new File(c.getFilesDir(), NAME); }

    public static synchronized void log(Context c, String type, String msg) {
        try {
            JSONObject o = new JSONObject();
            o.put("ts", System.currentTimeMillis());
            o.put("type", type == null ? "" : type);
            o.put("msg", msg == null ? "" : msg);
            File f = file(c);
            FileOutputStream fos = new FileOutputStream(f, true);
            fos.write((o.toString() + "\n").getBytes(StandardCharsets.UTF_8));
            fos.close();
            trim(c, f);
        } catch (Exception ignored) {}
    }

    public static void log(Context c, String type, Throwable t) {
        log(c, type, stack(t));
    }

    private static void trim(Context c, File f) {
        try {
            List<String> lines = Files.readAllLines(f.toPath(), StandardCharsets.UTF_8);
            if (lines.size() > MAX) {
                lines = new ArrayList<>(lines.subList(lines.size() - MAX, lines.size()));
                File tmp = new File(c.getFilesDir(), "runlog.tmp");
                Files.write(tmp.toPath(), lines, StandardCharsets.UTF_8);
                File target = file(c);
                target.delete();
                tmp.renameTo(target);
            }
        } catch (Exception ignored) {}
    }

    public static synchronized List<JSONObject> entries(Context c) {
        List<JSONObject> out = new ArrayList<>();
        try {
            for (String line : Files.readAllLines(file(c).toPath(), StandardCharsets.UTF_8)) {
                try { out.add(new JSONObject(line)); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static synchronized void clear(Context c) {
        try { Files.deleteIfExists(file(c).toPath()); } catch (Exception ignored) {}
    }

    public static String stack(Throwable t) {
        if (t == null) return "";
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        String s = sw.toString();
        return s.length() > 2000 ? s.substring(0, 2000) : s;
    }

    /** 类型 → 本地化文案（调用方传入资源 id 查找） */
    public static int typeRes(String type) {
        if (T_COPY.equals(type)) return com.mc.cmd.assistant.R.string.log_type_copy;
        if (T_API.equals(type)) return com.mc.cmd.assistant.R.string.log_type_api;
        if (T_FLOAT.equals(type)) return com.mc.cmd.assistant.R.string.log_type_float;
        if (T_CRASH.equals(type)) return com.mc.cmd.assistant.R.string.log_type_crash;
        if (T_SOURCE.equals(type)) return com.mc.cmd.assistant.R.string.log_type_source;
        if (T_APP.equals(type)) return com.mc.cmd.assistant.R.string.log_type_app;
        return com.mc.cmd.assistant.R.string.log_type_other;
    }

    public static JSONArray toJson(Context c) {
        JSONArray a = new JSONArray();
        for (JSONObject o : entries(c)) a.put(o);
        return a;
    }
}
