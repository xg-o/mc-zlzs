package com.mc.cmd.assistant.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.data.Models.SearchResult;

import java.util.ArrayList;
import java.util.List;
import com.mc.cmd.assistant.BaseActivity;

public class SearchActivity extends BaseActivity {

    private SearchAdapter adapter;
    private final List<Object> items = new ArrayList<>();
    private TextView hint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        ((MaterialToolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(x -> finish());
        hint = findViewById(R.id.searchHint);
        hint.setText(R.string.search_hint_guide);

        RecyclerView rv = findViewById(R.id.searchList);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SearchAdapter(items);
        rv.setAdapter(adapter);

        TextInputEditText et = findViewById(R.id.globalSearch);
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                doSearch(et.getText() == null ? "" : et.getText().toString().trim());
            }
        });
        String pre = getIntent().getStringExtra("q");
        if (pre != null) et.setText(pre);
        else doSearch("");
    }

    private void doSearch(String q) {
        items.clear();
        if (q.isEmpty()) {
            hint.setText(R.string.search_hint_empty);
        } else {
            SearchResult r = DataStore.get().search(q);
            if (new Prefs(SearchActivity.this).getBuiltinEnabled()) {
                items.addAll(r.presets);
            } else {
                java.util.Set<String> src = new java.util.HashSet<>();
                for (com.mc.cmd.assistant.data.Models.Preset p : new Prefs(SearchActivity.this).sourcePresets()) src.add(p.cmd);
                for (com.mc.cmd.assistant.data.Models.Preset p : r.presets) if (src.contains(p.cmd)) items.add(p);
            }
            items.addAll(r.ids);
            hint.setText(getString(R.string.search_result_count, r.presets.size(), r.ids.size()));
        }
        adapter.notifyDataSetChanged();
    }
}
