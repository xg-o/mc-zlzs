package com.mc.cmd.assistant.util;

import android.content.Context;
import android.graphics.Color;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Prefs;

/** 主题：预设 6 套 + 自定义种子色（Android 12+ 动态取色） */
public class ThemeUtil {

    public static final String[] THEME_IDS = {"purple", "green", "blue", "orange", "red", "pink", "custom"};
    public static final int[] THEME_SEEDS = {
            0xFF6750A4, 0xFF2E7D32, 0xFF1565C0, 0xFFE65100, 0xFFC62828, 0xFFC2185B, 0xFF000000
    };

    public static int styleRes(String id) {
        if ("green".equals(id)) return R.style.Theme_MCAssistant_Green;
        if ("blue".equals(id)) return R.style.Theme_MCAssistant_Blue;
        if ("orange".equals(id)) return R.style.Theme_MCAssistant_Orange;
        if ("red".equals(id)) return R.style.Theme_MCAssistant_Red;
        if ("pink".equals(id)) return R.style.Theme_MCAssistant_Pink;
        return R.style.Theme_MCAssistant;
    }

    public static boolean isCustom(String id) { return "custom".equals(id); }


    /** 取主题属性颜色（按资源名运行时解析，兼容库 attr） */
    public static int resolveColor(Context c, String attrName) {
        int id = c.getResources().getIdentifier(attrName, "attr", c.getPackageName());
        android.util.TypedValue tv = new android.util.TypedValue();
        if (id != 0 && c.getTheme().resolveAttribute(id, tv, true)) return tv.data;
        return 0xFF6750A4;
    }

    public static int customColor(Context c) {
        String hex = new Prefs(c).getThemeCustom();
        try {
            if (hex != null && hex.startsWith("#") && hex.length() == 7) return Color.parseColor(hex);
        } catch (Exception ignored) {}
        return 0;
    }
}
