package com.mc.cmd.assistant.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.Prefs;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** 命令本条目（AI 生成/保存的命令） */
public class BookAdapter extends RecyclerView.Adapter<BookAdapter.VH> {
    private final List<JSONObject> items;
    private final Runnable onChanged;

    public BookAdapter(List<JSONObject> items, Runnable onChanged) {
        this.items = items;
        this.onChanged = onChanged;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_fav, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        JSONObject o = items.get(pos);
        String cmd = o.optString("cmd");
        long ts = o.optLong("ts");
        h.cmd.setText(cmd);
        h.label.setText(new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(new Date(ts)));
        h.copy.setOnClickListener(x -> Clip.copy(h.itemView.getContext(), cmd));
        h.remove.setImageResource(R.drawable.ic_delete);
        h.remove.setOnClickListener(x -> {
            new Prefs(h.itemView.getContext()).removeAiSaved(ts, cmd);
            if (onChanged != null) onChanged.run();
        });
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView cmd, label;
        ImageButton copy, remove;

        VH(@NonNull View v) {
            super(v);
            cmd = v.findViewById(R.id.favCmd);
            label = v.findViewById(R.id.favLabel);
            copy = v.findViewById(R.id.favCopy);
            remove = v.findViewById(R.id.favRemove);
        }
    }
}
