package com.mc.cmd.assistant.floating;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.ai.AiClient;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Models;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.data.RunLog;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 悬浮窗小助手：拖拽圆钮 + 面板内直接操作（最近/拼接/预览/ID/AI），复制后无需退出游戏 */
public class FloatingService extends Service {

    private static boolean running = false;

    public static boolean isRunning() { return running; }

    private WindowManager wm;
    private WindowManager.LayoutParams btnParams, panelParams;
    private View button, panel;
    private boolean expanded;
    private int startX, startY, initX, initY;
    private boolean moved;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private String view = "recent";
    private Models.Template curTpl;
    private List<Models.Template> tpls = new ArrayList<>();
    private final List<Button> tplBtns = new ArrayList<>();

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        try {
            startForegroundCompat();
        } catch (Exception e) {
            RunLog.log(this, RunLog.T_FLOAT, e);
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (!Settings.canDrawOverlays(this)) {
            RunLog.log(this, RunLog.T_FLOAT, "无悬浮窗权限，服务退出");
            running = false;
            stopSelf();
            return;
        }
        try {
            addButton();
            RunLog.log(this, RunLog.T_FLOAT, "悬浮窗已显示");
        } catch (Exception e) {
            RunLog.log(this, RunLog.T_FLOAT, e);
            running = false;
            stopSelf();
        }
    }

    private void startForegroundCompat() {
        String chId = "float_channel";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(chId, getString(R.string.float_channel), NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        Notification n = new Notification.Builder(this, chId)
                .setSmallIcon(R.drawable.ic_floating)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.float_running))
                .setOngoing(true)
                .build();
        try {
            startForeground(101, n);
        } catch (Exception e) {
            try { stopForeground(STOP_FOREGROUND_DETACH); } catch (Exception ignored) {}
        }
    }

    private void addButton() {
        button = LayoutInflater.from(this).inflate(R.layout.view_floating_button, null);
        btnParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        btnParams.gravity = Gravity.TOP | Gravity.START;
        btnParams.x = 100;
        btnParams.y = 300;
        wm.addView(button, btnParams);

        button.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = (int) e.getRawX();
                    startY = (int) e.getRawY();
                    initX = btnParams.x;
                    initY = btnParams.y;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) e.getRawX() - startX;
                    int dy = (int) e.getRawY() - startY;
                    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) moved = true;
                    btnParams.x = initX + dx;
                    btnParams.y = initY + dy;
                    wm.updateViewLayout(button, btnParams);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) toggle();
                    return true;
            }
            return false;
        });
    }

    private void toggle() {
        try {
            if (expanded) collapse(); else expand();
        } catch (Exception e) {
            RunLog.log(this, RunLog.T_FLOAT, e);
            Toast.makeText(this, getString(R.string.float_open_fail, e.getMessage()), Toast.LENGTH_LONG).show();
            try { collapse(); } catch (Exception ignored) {}
        }
    }

    private void expand() {
        if (expanded) return;
        try {
            expandInner();
        } catch (Exception e) {
            RunLog.log(this, RunLog.T_FLOAT, e);
            throw e;
        }
    }

    private void expandInner() {
        panel = LayoutInflater.from(this).inflate(R.layout.view_floating_window, null);
        panelParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        android.graphics.Point size = new android.graphics.Point();
        wm.getDefaultDisplay().getSize(size);
        panelParams.width = Math.min(dp(340), size.x - dp(16));
        int px = btnParams.x - dp(30);
        if (px + panelParams.width > size.x - dp(8)) px = size.x - panelParams.width - dp(8);
        if (px < dp(4)) px = dp(4);
        int py = btnParams.y + btnParams.height + dp(6);
        if (py + dp(340) > size.y - dp(8)) py = Math.max(dp(4), btnParams.y - dp(350));
        panelParams.x = px;
        panelParams.y = py;
        wm.addView(panel, panelParams);

        panel.findViewById(R.id.floatClose).setOnClickListener(x -> collapse());
        panel.findViewById(R.id.floatRecent).setOnClickListener(x -> showView("recent"));
        panel.findViewById(R.id.floatBuilder).setOnClickListener(x -> showView("builder"));
        panel.findViewById(R.id.floatPreset).setOnClickListener(x -> showView("preset"));
        panel.findViewById(R.id.floatIds).setOnClickListener(x -> showView("ids"));
        panel.findViewById(R.id.floatAi).setOnClickListener(x -> showView("ai"));
        showView("recent");
        expanded = true;
    }

    // ================= 视图系统 =================
    private void showView(String v) {
        if (panel == null) return;
        view = v;
        FrameLayout body = panel.findViewById(R.id.floatBody);
        if (body == null) return;
        body.removeAllViews();
        TextView title = panel.findViewById(R.id.floatTitle);
        if ("builder".equals(v)) { title.setText(R.string.float_builder); renderBuilder(body); }
        else if ("preset".equals(v)) { title.setText(R.string.float_preset); renderPreset(body); }
        else if ("ids".equals(v)) { title.setText(R.string.float_ids); renderIds(body); }
        else if ("ai".equals(v)) { title.setText(R.string.float_ai); renderAi(body); }
        else { title.setText(R.string.float_title); renderRecent(body); }
        int[] ids = {R.id.floatRecent, R.id.floatBuilder, R.id.floatPreset, R.id.floatIds, R.id.floatAi};
        String[] vs = {"recent", "builder", "preset", "ids", "ai"};
        for (int i = 0; i < ids.length; i++) {
            Button b = panel.findViewById(ids[i]);
            boolean act = vs[i].equals(v);
            b.setBackgroundResource(act ? R.drawable.bg_float_btn : R.drawable.bg_float_btn_ghost);
            b.setTextColor(act ? 0xFFFFFFFF : 0xFF6750A4);
        }
        RunLog.log(this, RunLog.T_FLOAT, "悬浮窗视图 " + v);
    }

    private LinearLayout listHost(ViewGroup parent) {
        ScrollView sv = new ScrollView(this);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        sv.addView(ll);
        sv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)));
        parent.addView(sv);
        return ll;
    }

    private void renderRecent(FrameLayout body) {
        LinearLayout ll = listHost(body);
        Prefs prefs = new Prefs(this);
        List<String> recents = prefs.getLastCmds();
        if (recents.isEmpty()) {
            TextView tv = text(getString(R.string.float_empty), 12.5f, 0x99000000);
            tv.setPadding(dp(4), dp(10), dp(4), dp(10));
            ll.addView(tv);
        } else {
            int n = Math.min(20, recents.size());
            for (int i = 0; i < n; i++) ll.addView(delCmdRow(recents.get(i)));
        }
    }

    private LinearLayout delCmdRow(final String cmd) {
        LinearLayout row = cmdRow(cmd);
        ImageButton del = new ImageButton(this);
        del.setImageResource(R.drawable.ic_close);
        del.setBackgroundResource(R.drawable.bg_float_close);
        del.setImageTintList(android.content.res.ColorStateList.valueOf(0xFF7A6A8F));
        del.setPadding(dp(5), dp(5), dp(5), dp(5));
        del.setContentDescription(getString(R.string.float_del));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(26), dp(26));
        dlp.setMarginStart(dp(2));
        del.setLayoutParams(dlp);
        del.setOnClickListener(x -> {
            new Prefs(this).removeLastCmd(cmd);
            showView("recent");
        });
        row.addView(del);
        return row;
    }

    private void renderBuilder(FrameLayout body) {
        Prefs prefs = new Prefs(this);
        DataStore ds = DataStore.get();
        tpls = new ArrayList<>();
        if (prefs.getBuiltinEnabled()) tpls.addAll(ds.templates);
        tpls.addAll(prefs.sourceTemplates());

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        body.addView(col);

        if (tpls.isEmpty()) {
            col.addView(text(getString(R.string.float_empty), 12.5f, 0x99000000));
            return;
        }
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        tplBtns.clear();
        for (Models.Template t : tpls) {
            Button b = new Button(this);
            b.setText(t.n);
            b.setTextSize(11.5f);
            b.setMinHeight(dp(30));
            b.setAllCaps(false);
            b.setOnClickListener(x -> {
                curTpl = t;
                showTplOut(col);
                highlightTpl(b);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(dp(6));
            b.setLayoutParams(lp);
            chipRow.addView(b);
            tplBtns.add(b);
        }
        hsv.addView(chipRow);
        col.addView(hsv);

        TextView out = text("", 13f, 0xFF1C1B1F);
        out.setTypeface(Typeface.MONOSPACE);
        out.setPadding(dp(4), dp(6), dp(4), dp(4));
        col.addView(out);

        Button copy = new Button(this);
        copy.setBackgroundResource(R.drawable.bg_float_btn);
        copy.setText(R.string.float_copy_tpl);
        copy.setTextColor(0xFFFFFFFF);
        copy.setTextSize(12.5f);
        copy.setMinHeight(dp(36));
        copy.setOnClickListener(x -> { if (curTpl != null) copyCmd(curTpl.s); });
        col.addView(copy);

        curTpl = tpls.get(0);
        showTplOut(col);
        if (!tplBtns.isEmpty()) highlightTpl(tplBtns.get(0));
    }

    private void highlightTpl(Button sel) {
        for (Button b : tplBtns) {
            boolean act = b == sel;
            b.setBackgroundResource(act ? R.drawable.bg_float_btn : R.drawable.bg_float_btn_ghost);
            b.setTextColor(act ? 0xFFFFFFFF : 0xFF6750A4);
        }
    }

    private void showTplOut(LinearLayout col) {
        TextView out = (TextView) col.getChildAt(1);
        if (out == null || curTpl == null) return;
        out.setText(curTpl.s);
    }

    private void renderPreset(FrameLayout body) {
        Prefs prefs = new Prefs(this);
        DataStore ds = DataStore.get();
        List<Models.Preset> all = new ArrayList<>();
        if (prefs.getBuiltinEnabled()) all.addAll(ds.presets);
        all.addAll(prefs.sourcePresets());

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        body.addView(col);

        col.addView(text(getString(R.string.float_count, all.size()), 11.5f, 0x66000000));
        EditText search = searchBox(getString(R.string.float_search));
        col.addView(search);
        LinearLayout list = listHost(col);

        Runnable fill = () -> {
            list.removeAllViews();
            String q = search.getText() == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
            int n = 0;
            for (Models.Preset p : all) {
                if (n >= 50) break;
                String hay = (p.cmd + " " + p.d).toLowerCase(Locale.ROOT);
                if (q.isEmpty() || hay.contains(q)) {
                    list.addView(cmdRow(p.cmd + (p.d == null || p.d.isEmpty() ? "" : "　" + p.d), p.cmd));
                    n++;
                }
            }
            if (n == 0) {
                TextView tv = text(getString(R.string.float_empty), 12.5f, 0x99000000);
                tv.setPadding(dp(4), dp(10), dp(4), dp(10));
                list.addView(tv);
            }
        };
        search.addTextChangedListener(simpleWatcher(fill));
        fill.run();
    }

    private void renderIds(FrameLayout body) {
        Prefs prefs = new Prefs(this);
        DataStore ds = DataStore.get();
        List<Models.IdEntry> all = new ArrayList<>();
        if (prefs.getBuiltinEnabled()) all.addAll(ds.flatIds());
        all.addAll(prefs.sourceIds());

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        body.addView(col);

        col.addView(text(getString(R.string.float_count, all.size()), 11.5f, 0x66000000));
        EditText search = searchBox(getString(R.string.float_search));
        col.addView(search);
        LinearLayout list = listHost(col);

        Runnable fill = () -> {
            list.removeAllViews();
            String q = search.getText() == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
            int n = 0;
            for (Models.IdEntry e : all) {
                if (n >= 50) break;
                String hay = (e.id + " " + (e.name == null ? "" : e.name)).toLowerCase(Locale.ROOT);
                if (q.isEmpty() || hay.contains(q)) {
                    String label = e.id + (e.name == null || e.name.isEmpty() ? "" : "　" + e.name);
                    list.addView(cmdRow(label, e.id));
                    n++;
                }
            }
            if (n == 0) {
                TextView tv = text(getString(R.string.float_empty), 12.5f, 0x99000000);
                tv.setPadding(dp(4), dp(10), dp(4), dp(10));
                list.addView(tv);
            }
        };
        search.addTextChangedListener(simpleWatcher(fill));
        fill.run();
    }

    private void renderAi(FrameLayout body) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        body.addView(col);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        EditText input = new EditText(this);
        input.setHint(R.string.float_ai_hint);
        input.setTextSize(13f);
        input.setSingleLine(true);
        input.setBackgroundResource(R.drawable.bg_float_input);
        input.setPadding(dp(8), dp(6), dp(8), dp(6));
        row.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button send = new Button(this);
        send.setBackgroundResource(R.drawable.bg_float_btn);
        send.setText(R.string.float_ai_send);
        send.setTextColor(0xFFFFFFFF);
        send.setTextSize(12f);
        send.setMinHeight(dp(36));
        row.addView(send);
        col.addView(row);

        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)));
        TextView out = text(getString(R.string.float_ai_ready), 12.5f, 0x99000000);
        out.setPadding(dp(4), dp(8), dp(4), dp(4));
        sv.addView(out);
        col.addView(sv);

        Button copy = new Button(this);
        copy.setBackgroundResource(R.drawable.bg_float_btn_ghost);
        copy.setText(R.string.float_copy_result);
        copy.setTextColor(0xFF6750A4);
        copy.setTextSize(12f);
        copy.setMinHeight(dp(36));
        copy.setOnClickListener(x -> {
            String s = out.getText() == null ? "" : out.getText().toString();
            if (!s.isEmpty() && !s.equals(getString(R.string.float_ai_ready))) copyCmd(s);
        });
        col.addView(copy);

        send.setOnClickListener(x -> {
            final String prompt = input.getText() == null ? "" : input.getText().toString().trim();
            if (prompt.isEmpty()) return;
            out.setText(getString(R.string.float_ai_working));
            Prefs prefs = new Prefs(this);
            JSONObject st = prefs.getSettings();
            String base = AiClient.resolveBase(st, DataStore.get().providers);
            if (base.isEmpty()) {
                out.setText(getString(R.string.float_ai_noapi));
                return;
            }
            new Thread(() -> {
                try {
                    JSONArray messages = new JSONArray();
                    JSONObject sys = new JSONObject();
                    sys.put("role", "system");
                    sys.put("content", st.optString("systemPrompt", DataStore.get().defaultPrompt));
                    messages.put(sys);
                    JSONObject u = new JSONObject();
                    u.put("role", "user");
                    u.put("content", prompt);
                    messages.put(u);
                    final String reply = AiClient.chat(base, st, messages);
                    ui.post(() -> out.setText(reply));
                } catch (Exception e) {
                    final String msg = e.getMessage() == null ? "error" : e.getMessage();
                    RunLog.log(FloatingService.this, RunLog.T_FLOAT, "AI生成失败 " + msg);
                    ui.post(() -> out.setText(getString(R.string.float_ai_fail, msg)));
                }
            }).start();
        });
    }

    // ================= 通用组件 =================
    private TextView text(String s, float size, int color) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(size);
        tv.setTextColor(color);
        return tv;
    }

    private EditText searchBox(String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setTextSize(13f);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setBackgroundResource(R.drawable.bg_float_input);
        et.setPadding(dp(8), dp(6), dp(8), dp(6));
        return et;
    }

    private android.text.TextWatcher simpleWatcher(final Runnable r) {
        return new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable s) { r.run(); }
        };
    }

    private LinearLayout cmdRow(final String cmd) { return cmdRow(cmd, cmd); }

    private LinearLayout cmdRow(final String label, final String copyText) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(4), dp(2), dp(4));
        TextView code = new TextView(this);
        code.setText(label);
        code.setTextSize(12f);
        code.setSingleLine(true);
        code.setEllipsize(android.text.TextUtils.TruncateAt.END);
        code.setTextColor(0xFF1C1B1F);
        row.addView(code, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ImageButton copy = new ImageButton(this);
        copy.setImageResource(R.drawable.ic_copy);
        copy.setBackground(null);
        copy.setImageTintList(android.content.res.ColorStateList.valueOf(0xFF6750A4));
        copy.setOnClickListener(x -> copyCmd(copyText));
        row.addView(copy);
        row.setOnClickListener(x -> copyCmd(copyText));
        return row;
    }

    private void copyCmd(String cmd) {
        Clip.copy(this, cmd);
        new Prefs(this).pushLastCmd(cmd);
        Toast.makeText(this, R.string.float_copied, Toast.LENGTH_SHORT).show();
        RunLog.log(this, RunLog.T_COPY, "悬浮窗复制 " + cmd);
    }

    private void collapse() {
        if (panel != null && panel.isAttachedToWindow()) wm.removeView(panel);
        panel = null;
        expanded = false;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (button != null && button.isAttachedToWindow()) wm.removeView(button);
            if (panel != null && panel.isAttachedToWindow()) wm.removeView(panel);
            RunLog.log(this, RunLog.T_FLOAT, "悬浮窗已关闭");
        } catch (Exception e) {
            RunLog.log(this, RunLog.T_FLOAT, e);
        }
        super.onDestroy();
    }
}
