package com.mc.cmd.assistant.ai;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Prefs;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** AI 会话列表（分类筛选由外部完成） */
public class ConvAdapter extends RecyclerView.Adapter<ConvAdapter.VH> {

    public interface Listener {
        void onOpen(JSONObject conv);
        void onDelete(JSONObject conv);
    }

    private final List<JSONObject> items;
    private final Listener listener;
    private final Prefs prefs;

    public ConvAdapter(List<JSONObject> items, Prefs prefs, Listener listener) {
        this.items = items;
        this.prefs = prefs;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_conv, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        JSONObject o = items.get(pos);
        h.title.setText(o.optString("title"));
        String cat = o.optString("cat", "default");
        int catRes = catRes(cat);
        h.cat.setText(catRes);
        h.cat.setVisibility(View.VISIBLE);
        long ts = o.optLong("ts");
        h.time.setText(new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(new Date(ts)));
        String cur = prefs.getCurrentConv();
        h.itemView.setAlpha(cur != null && cur.equals(o.optString("id")) ? 1f : 0.55f);
        h.itemView.setOnClickListener(x -> { if (listener != null) listener.onOpen(o); });
        h.del.setOnClickListener(x -> { if (listener != null) listener.onDelete(o); });
    }

    public static int catRes(String cat) {
        if ("survival".equals(cat)) return R.string.conv_cat_survival;
        if ("creative".equals(cat)) return R.string.conv_cat_creative;
        if ("redstone".equals(cat)) return R.string.conv_cat_redstone;
        if ("build".equals(cat)) return R.string.conv_cat_build;
        if ("battle".equals(cat)) return R.string.conv_cat_battle;
        if ("other".equals(cat)) return R.string.conv_cat_other;
        return R.string.conv_cat_default;
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, cat, time;
        ImageButton del;

        VH(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.convTitle);
            cat = v.findViewById(R.id.convCat);
            time = v.findViewById(R.id.convTime);
            del = v.findViewById(R.id.convDel);
        }
    }
}
