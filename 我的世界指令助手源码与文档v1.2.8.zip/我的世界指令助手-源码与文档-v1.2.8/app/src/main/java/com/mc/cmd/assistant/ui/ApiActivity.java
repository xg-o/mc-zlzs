package com.mc.cmd.assistant.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.google.android.material.appbar.MaterialToolbar;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Models.IdEntry;
import com.mc.cmd.assistant.data.Models.Preset;
import com.mc.cmd.assistant.data.Prefs;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import com.mc.cmd.assistant.BaseActivity;

/** 键盘联动 API：导出数据 JSON + 接口文档（键盘项目后续单独开发） */
public class ApiActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_api);
        ((MaterialToolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(x -> finish());

        String sample = buildSample();
        ((TextView) findViewById(R.id.apiSample)).setText(sample);

        findViewById(R.id.apiCopySample).setOnClickListener(x -> Clip.copy(this, sample));
        findViewById(R.id.apiExport).setOnClickListener(x -> export());
    }

    private String buildSample() {
        try {
            DataStore ds = DataStore.get();
            JSONObject root = new JSONObject();
            root.put("app", "mc-cmd-assistant");
            root.put("version", "1.0.0");
            JSONObject data = new JSONObject();
            JSONArray pa = new JSONArray();
            int n = Math.min(2, ds.presets.size());
            for (int i = 0; i < n; i++) {
                Preset p = ds.presets.get(i);
                pa.put(new JSONObject().put("c", p.c).put("cmd", p.cmd).put("d", p.d).put("t", p.t));
            }
            data.put("presets", pa);
            JSONObject ids = new JSONObject();
            for (String k : new String[]{"blocks", "particles", "sounds"}) {
                List<IdEntry> l = ds.ids.get(k);
                JSONArray arr = new JSONArray();
                if (l != null) {
                    int m = Math.min(2, l.size());
                    for (int i = 0; i < m; i++) {
                        IdEntry e = l.get(i);
                        arr.put(new JSONArray().put(e.id).put(e.name == null ? "" : e.name).put(e.note == null ? "" : e.note));
                    }
                }
                ids.put(k, arr);
            }
            data.put("ids", ids);
            data.put("templates", ds.templates.size());
            root.put("data", data);
            return root.toString(1);
        } catch (Exception e) {
            return "{ error: " + e.getMessage() + " }";
        }
    }

    private void export() {
        try {
            Prefs prefs = new Prefs(this);
            DataStore ds = DataStore.get();
            JSONObject root = new JSONObject();
            root.put("app", "mc-cmd-assistant");
            root.put("version", "1.0.0");
            JSONObject data = new JSONObject();
            JSONArray pa = new JSONArray();
            for (Preset p : ds.presets) {
                pa.put(new JSONObject().put("c", p.c).put("cmd", p.cmd).put("d", p.d).put("t", p.t));
            }
            data.put("presets", pa);
            JSONObject ids = new JSONObject();
            for (String k : ds.ids.keySet()) {
                JSONArray arr = new JSONArray();
                for (IdEntry e : ds.ids.get(k)) {
                    arr.put(new JSONArray().put(e.id).put(e.name == null ? "" : e.name).put(e.note == null ? "" : e.note));
                }
                ids.put(k, arr);
            }
            data.put("ids", ids);
            root.put("data", data);
            root.put("user", new JSONObject().put("favorites", prefs.getFavs()).put("aiSaved", prefs.getAiSaved()).put("settings", prefs.getSettings()));

            File dir = new File(getCacheDir(), "export");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "mc-command-assistant-data.json");
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(root.toString(1).getBytes(StandardCharsets.UTF_8));
            fos.close();
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/json");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, getString(R.string.export_share_title)));
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.data_export_fail, e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }
}
