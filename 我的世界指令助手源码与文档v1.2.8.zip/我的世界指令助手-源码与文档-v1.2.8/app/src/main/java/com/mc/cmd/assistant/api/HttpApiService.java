package com.mc.cmd.assistant.api;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.RunLog;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Models.IdEntry;
import com.mc.cmd.assistant.data.Models.Preset;
import com.mc.cmd.assistant.data.Prefs;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

/** 本地 API 服务：供其它应用（如第三方键盘）读取指令数据。仅监听本机与局域网，明文 JSON。 */
public class HttpApiService extends Service {

    private static final String TAG = "HttpApi";
    public static volatile boolean running = false;
    public static volatile int port = 0;

    private ServerSocket server;
    private Thread thread;

    public static boolean isRunning() { return running; }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            startForegroundCompat();
            startServer();
            RunLog.log(this, RunLog.T_API, "API 服务启动，端口 " + new Prefs(this).getApiPort());
        } catch (Exception e) {
            RunLog.log(this, RunLog.T_API, e);
            try { stopSelf(); } catch (Exception ignored) {}
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private void startForegroundCompat() {
        String chId = "api_channel";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(chId, getString(R.string.dev_api_switch), NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        Notification n = new Notification.Builder(this, chId)
                .setSmallIcon(R.drawable.ic_api)
                .setContentTitle(getString(R.string.dev_api_switch))
                .setContentText(getString(R.string.dev_api_running))
                .setOngoing(true)
                .build();
        try {
            startForeground(102, n);
        } catch (Exception e) {
            RunLog.log(this, RunLog.T_API, e);
            try { stopForeground(STOP_FOREGROUND_DETACH); } catch (Exception ignored) {}
        }
    }

    private void startServer() {
        if (server != null && !server.isClosed() && thread != null && thread.isAlive()) return;
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        final int p = new Prefs(this).getApiPort();
        thread = new Thread(() -> {
            ServerSocket ss = null;
            try {
                ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(p));
                server = ss;
                running = true;
                port = p;
                RunLog.log(this, RunLog.T_API, "API 监听 0.0.0.0:" + p);
                while (running && !ss.isClosed()) {
                    Socket s = ss.accept();
                    handle(s);
                }
            } catch (Exception e) {
                Log.e(TAG, "server error", e);
                RunLog.log(this, RunLog.T_API, e);
                running = false;
                try { stopSelf(); } catch (Exception ignored) {}
            }
        });
        thread.start();
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(8000);
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            String line = r.readLine();
            if (line == null) { s.close(); return; }
            String[] parts = line.split(" ");
            String method = parts.length > 0 ? parts[0] : "GET";
            String path = parts.length > 1 ? parts[1] : "/";

            // 读取请求体（POST）
            int bodyLen = 0;
            String h;
            while ((h = r.readLine()) != null && !h.isEmpty()) {
                String lower = h.toLowerCase(Locale.ROOT);
                if (lower.startsWith("content-length:")) {
                    try { bodyLen = Integer.parseInt(h.split(":")[1].trim()); } catch (Exception ignored) {}
                }
            }
            StringBuilder body = new StringBuilder();
            for (int i = 0; i < bodyLen; i++) body.append((char) r.read());

            String resp = route(method, path, body.toString());
            byte[] out = resp.getBytes(StandardCharsets.UTF_8);
            StringBuilder head = new StringBuilder();
            head.append("HTTP/1.1 200 OK\r\n");
            head.append("Content-Type: application/json; charset=utf-8\r\n");
            head.append("Access-Control-Allow-Origin: *\r\n");
            head.append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n");
            head.append("Access-Control-Allow-Headers: Content-Type\r\n");
            head.append("Content-Length: ").append(out.length).append("\r\n");
            head.append("Connection: close\r\n\r\n");
            OutputStream os = s.getOutputStream();
            os.write(head.toString().getBytes(StandardCharsets.UTF_8));
            os.write(out);
            os.flush();
            s.close();
            if ("/inject".equals(path)) {
                try {
                    JSONObject j = new JSONObject(resp);
                    RunLog.log(this, RunLog.T_API, "注入剪贴板: " + j.optString("injected"));
                } catch (Exception ignored3) {}
            }
        } catch (Exception e) {
            RunLog.log(this, RunLog.T_API, "请求处理失败: " + e.getMessage());
            try { s.close(); } catch (Exception ignored2) {}
        }
    }

    private String route(String method, String path, String body) {
        try {
            String p = path;
            String query = "";
            int qi = p.indexOf('?');
            if (qi >= 0) { query = p.substring(qi + 1); p = p.substring(0, qi); }
            if (p.endsWith("/")) p = p.substring(0, p.length() - 1);
            if (p.isEmpty()) p = "/health";

            Prefs prefs = new Prefs(this);
            JSONObject root = new JSONObject();
            switch (p) {
                case "/health": {
                    root.put("ok", true);
                    root.put("app", "mc-cmd-assistant");
                    root.put("version", "1.1.0");
                    root.put("time", System.currentTimeMillis());
                    break;
                }
                case "/commands": {
                    JSONArray arr = new JSONArray(prefs.getLastCmds());
                    root.put("commands", arr);
                    break;
                }
                case "/favorites": {
                    root.put("favorites", prefs.getFavs());
                    break;
                }
                case "/presets": {
                    JSONArray arr = new JSONArray();
                    for (Preset ps : DataStore.get().presets) {
                        arr.put(new JSONObject().put("c", ps.c).put("cmd", ps.cmd).put("d", ps.d).put("t", ps.t));
                    }
                    root.put("presets", arr);
                    break;
                }
                case "/ids": {
                    String q = queryOf(query, "q");
                    JSONArray arr = new JSONArray();
                    for (IdEntry e : DataStore.get().flatIds()) {
                        String ql = q.toLowerCase(Locale.ROOT);
                        if (q.isEmpty() || e.id.toLowerCase(Locale.ROOT).contains(ql)
                                || (e.name != null && e.name.toLowerCase(Locale.ROOT).contains(ql))
                                || (e.note != null && e.note.toLowerCase(Locale.ROOT).contains(ql))) {
                            arr.put(new JSONObject().put("cat", e.cat).put("id", e.id).put("name", e.name == null ? "" : e.name).put("note", e.note == null ? "" : e.note));
                        }
                    }
                    root.put("ids", arr);
                    break;
                }
                case "/inject": {
                    if (!"POST".equals(method)) {
                        return err("use POST");
                    }
                    String cmd = "";
                    try {
                        JSONObject b = new JSONObject(body);
                        cmd = b.optString("command");
                    } catch (Exception ignored) {}
                    if (cmd.isEmpty()) return err("missing command");
                    Clip.copy(this, cmd);
                    root.put("ok", true);
                    root.put("injected", cmd);
                    break;
                }
                default:
                    return err("not found: " + p);
            }
            return root.toString();
        } catch (Exception e) {
            return err(e.getMessage());
        }
    }

    private String queryOf(String query, String key) {
        for (String kv : query.split("&")) {
            String[] pair = kv.split("=", 2);
            if (pair.length == 2 && pair[0].equals(key)) {
                try { return java.net.URLDecoder.decode(pair[1], "UTF-8"); } catch (Exception e) { return pair[1]; }
            }
        }
        return "";
    }

    private String err(String msg) {
        return "{\"ok\":false,\"error\":" + JSONObject.quote(msg == null ? "unknown" : msg) + "}";
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        try { RunLog.log(this, RunLog.T_API, "API 服务已停止"); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
