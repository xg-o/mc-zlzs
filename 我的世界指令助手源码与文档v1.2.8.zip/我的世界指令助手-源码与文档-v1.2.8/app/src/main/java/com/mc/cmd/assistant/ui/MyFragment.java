package com.mc.cmd.assistant.ui;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.floating.FloatingService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MyFragment extends Fragment {

    private Prefs prefs;
    private boolean wantStart;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_my, container, false);
        prefs = new Prefs(requireContext());

        setupEntry(v, R.id.entrySettings, R.drawable.ic_settings, R.string.my_settings, R.string.my_settings_sub,
                () -> startActivity(new Intent(getContext(), SettingsActivity.class)));

        setupEntry(v, R.id.entryAppearance, R.drawable.ic_chevron_right, R.string.my_appearance, R.string.my_appearance_sub,
                () -> startActivity(new Intent(getContext(), AppearanceActivity.class)));

        setupEntry(v, R.id.entryFloating, R.drawable.ic_floating, R.string.my_floating, R.string.my_floating_sub_off,
                () -> toggleFloating());

        setupEntry(v, R.id.entryVersion, R.drawable.ic_build, R.string.my_version, R.string.my_version_sub,
                () -> VersionDialog.show(requireContext(), prefs, null));

        setupEntry(v, R.id.entrySources, R.drawable.ic_add, R.string.my_sources, R.string.my_sources_sub,
                () -> startActivity(new Intent(getContext(), SourcesActivity.class)));

        setupEntry(v, R.id.entryLogs, R.drawable.ic_book, R.string.my_logs, R.string.my_logs_sub,
                () -> startActivity(new Intent(getContext(), LogActivity.class)));

        setupEntry(v, R.id.entryApi, R.drawable.ic_api, R.string.my_api, R.string.my_api_sub,
                () -> startActivity(new Intent(getContext(), ApiActivity.class)));

        setupEntry(v, R.id.entryData, R.drawable.ic_export, R.string.my_data, R.string.my_data_sub,
                () -> startActivity(new Intent(getContext(), DataActivity.class)));

        setupEntry(v, R.id.entryAbout, R.drawable.ic_person, R.string.my_about, R.string.my_about_sub,
                () -> startActivity(new Intent(getContext(), AboutActivity.class)));

        RecyclerView favRv = v.findViewById(R.id.favList);
        favRv.setLayoutManager(new LinearLayoutManager(getContext()));
        RecyclerView bookRv = v.findViewById(R.id.bookList);
        bookRv.setLayoutManager(new LinearLayoutManager(getContext()));
        refreshLists(v);

        v.findViewById(R.id.clearBook).setOnClickListener(x -> {
            if (prefs.getAiSaved().length() == 0) {
                Toast.makeText(requireContext(), R.string.my_book_empty_toast, Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(requireContext())
                    .setTitle(R.string.my_clear_book_title)
                    .setMessage(getString(R.string.my_clear_book_msg, prefs.getAiSaved().length()))
                    .setPositiveButton(R.string.my_clear_book, (d, w) -> { prefs.clearAiSaved(); refreshLists(v); })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
        });
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshFloatStatus();
        Context c = getContext();
        if (wantStart && c != null && Settings.canDrawOverlays(c)) {
            wantStart = false;
            startFloat(c);
        }
    }

    private void setupEntry(View v, int cardId, int iconRes, int titleRes, int subRes, Runnable act) {
        MaterialCardView card = v.findViewById(cardId);
        ImageView icon = card.findViewById(R.id.entryIcon);
        TextView t = card.findViewById(R.id.entryTitle);
        TextView s = card.findViewById(R.id.entrySub);
        icon.setImageResource(iconRes);
        t.setText(titleRes);
        s.setText(subRes);
        card.setOnClickListener(x -> act.run());
    }

    private void refreshFloatStatus() {
        View root = getView();
        if (root == null) return;
        Context c = getContext();
        boolean running = FloatingService.isRunning();
        int sub;
        if (running) sub = R.string.my_floating_sub_on;
        else if (c == null || !Settings.canDrawOverlays(c)) sub = R.string.my_floating_sub_need_perm;
        else sub = R.string.my_floating_sub_off;
        MaterialCardView card = root.findViewById(R.id.entryFloating);
        ((TextView) card.findViewById(R.id.entrySub)).setText(sub);
    }

    private void toggleFloating() {
        Context c = requireContext();
        if (!Settings.canDrawOverlays(c)) {
            wantStart = true;
            new AlertDialog.Builder(c)
                    .setTitle(R.string.my_float_perm_dialog_title)
                    .setMessage(R.string.my_float_perm_dialog_msg)
                    .setPositiveButton(R.string.my_float_goto, (d, w) -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.getPackageName())));
                        } catch (Exception e) {
                            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
                        }
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
        } else if (FloatingService.isRunning()) {
            c.stopService(new Intent(c, FloatingService.class));
            Toast.makeText(c, R.string.float_stopped_toast, Toast.LENGTH_SHORT).show();
            refreshFloatStatus();
        } else {
            requestNotifIfNeeded();
            startFloat(c);
        }
    }

    private void requestNotifIfNeeded() {
        Context c = getContext();
        if (c == null || Build.VERSION.SDK_INT < 33) return;
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }

    private void startFloat(Context c) {
        try {
            c.startForegroundService(new Intent(c, FloatingService.class));
            Toast.makeText(c, R.string.float_running_toast, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(c, getString(R.string.float_open_fail, e.getMessage()), Toast.LENGTH_LONG).show();
        }
        refreshFloatStatus();
    }

    private void refreshLists(View v) {
        JSONArray favs = prefs.getFavs();
        List<JSONObject> favItems = new ArrayList<>();
        for (int i = 0; i < favs.length(); i++) favItems.add(favs.optJSONObject(i));
        RecyclerView favRv = v.findViewById(R.id.favList);
        FavAdapter favAd = new FavAdapter(favItems, () -> refreshLists(v));
        favRv.setAdapter(favAd);
        v.findViewById(R.id.favEmpty).setVisibility(favItems.isEmpty() ? View.VISIBLE : View.GONE);

        JSONArray saved = prefs.getAiSaved();
        List<JSONObject> savedItems = new ArrayList<>();
        for (int i = 0; i < saved.length(); i++) savedItems.add(saved.optJSONObject(i));
        RecyclerView bookRv = v.findViewById(R.id.bookList);
        bookRv.setAdapter(new BookAdapter(savedItems, () -> refreshLists(v)));
        v.findViewById(R.id.bookEmpty).setVisibility(savedItems.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
