package com.mc.cmd.assistant.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.Models.IdEntry;
import com.mc.cmd.assistant.data.Prefs;

import java.util.List;

public class IdsAdapter extends RecyclerView.Adapter<IdsAdapter.VH> {
    private final List<IdEntry> items;

    public IdsAdapter(List<IdEntry> items) { this.items = items; }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_id, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        IdEntry e = items.get(pos);
        Prefs prefs = new Prefs(h.itemView.getContext());
        h.id.setText(e.id);
        h.name.setText(e.name == null || e.name.isEmpty() ? (e.note == null ? "" : e.note) : e.name);
        h.note.setText(e.note == null ? "" : e.note);
        if (h.name.getText().equals(e.note)) h.note.setText("");

        String ref = e.cat + "|" + e.id;
        h.copy.setOnClickListener(x -> Clip.copy(h.itemView.getContext(), e.id));
        h.star.setOnClickListener(x -> {
            boolean on = prefs.toggleFav("id", ref, e.name, e.id, e.note);
            h.star.setImageResource(on ? R.drawable.ic_star_filled : R.drawable.ic_star);
            Toast.makeText(h.itemView.getContext(), on ? R.string.fav_added : R.string.fav_removed, Toast.LENGTH_SHORT).show();
        });
        h.star.setImageResource(prefs.isFav("id", ref) ? R.drawable.ic_star_filled : R.drawable.ic_star);
        h.itemView.setOnClickListener(x -> Clip.copy(h.itemView.getContext(), e.id));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView id, name, note;
        ImageButton copy, star;
        View itemView;

        VH(@NonNull View v) {
            super(v);
            itemView = v;
            id = v.findViewById(R.id.idv);
            name = v.findViewById(R.id.idName);
            note = v.findViewById(R.id.idNote);
            copy = v.findViewById(R.id.idCopy);
            star = v.findViewById(R.id.idStar);
        }
    }
}
