package com.mc.cmd.assistant.ai;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.mc.cmd.assistant.BaseActivity;
import com.mc.cmd.assistant.R;
import com.mc.cmd.assistant.data.Clip;
import com.mc.cmd.assistant.data.DataStore;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.ui.SettingsActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AiActivity extends BaseActivity {

    private final List<AiAdapter.Msg> msgs = new ArrayList<>();
    private AiAdapter adapter;
    private Prefs prefs;
    private EditText input;
    private MaterialButton send;
    private boolean sending;
    private JSONObject current;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai);
        prefs = new Prefs(this);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(x -> finish());
        toolbar.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.action_convs) { showConvs(); return true; }
            if (id == R.id.action_book) { showBook(); return true; }
            if (id == R.id.action_settings) { startActivity(new android.content.Intent(this, SettingsActivity.class)); return true; }
            return false;
        });

        RecyclerView rv = findViewById(R.id.aiList);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AiAdapter(msgs);
        rv.setAdapter(adapter);

        input = findViewById(R.id.aiIn);
        send = findViewById(R.id.aiSend);

        loadOrCreateCurrent();

        String pre = getIntent().getStringExtra("prompt");
        if (pre != null && !pre.isEmpty()) {
            input.setText(pre);
            send();
        }
        if (msgs.isEmpty()) {
            msgs.add(new AiAdapter.Msg(false, getString(R.string.ai_welcome)));
        }
        adapter.notifyDataSetChanged();
        scrollBottom();

        send.setOnClickListener(x -> send());
    }

    private void loadOrCreateCurrent() {
        JSONArray convs = prefs.getConvs();
        String curId = prefs.getCurrentConv();
        if (curId != null && !curId.isEmpty()) {
            for (int i = 0; i < convs.length(); i++) {
                JSONObject o = convs.optJSONObject(i);
                if (o != null && curId.equals(o.optString("id"))) { current = o; break; }
            }
        }
        if (current == null) {
            current = newConv(getString(R.string.conv_default_title), "default");
            prefs.pushConv(current);
            prefs.setCurrentConv(current.optString("id"));
        }
        toolbar.setTitle(current.optString("title"));
        JSONArray m = current.optJSONArray("msgs");
        msgs.clear();
        if (m != null) {
            for (int i = 0; i < m.length(); i++) {
                JSONObject o = m.optJSONObject(i);
                msgs.add(new AiAdapter.Msg("user".equals(o.optString("role")), o.optString("content")));
            }
        }
    }

    private JSONObject newConv(String title, String cat) {
        try {
            JSONObject o = new JSONObject();
            o.put("id", UUID.randomUUID().toString());
            o.put("title", title == null || title.isEmpty() ? getString(R.string.conv_default_title) : title);
            o.put("cat", cat == null ? "default" : cat);
            o.put("ts", System.currentTimeMillis());
            o.put("msgs", new JSONArray());
            return o;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void saveCurrent() {
        try {
            JSONArray m = new JSONArray();
            int start = Math.max(0, msgs.size() - 30);
            for (int i = start; i < msgs.size(); i++) {
                AiAdapter.Msg msg = msgs.get(i);
                JSONObject o = new JSONObject();
                o.put("role", msg.isUser ? "user" : "assistant");
                o.put("content", msg.text);
                m.put(o);
            }
            current.put("msgs", m);
            current.put("ts", System.currentTimeMillis());
            JSONArray convs = prefs.getConvs();
            JSONArray na = new JSONArray();
            String id = current.optString("id");
            for (int i = 0; i < convs.length(); i++) {
                JSONObject o = convs.optJSONObject(i);
                if (o != null && id.equals(o.optString("id"))) na.put(current);
                else na.put(o);
            }
            prefs.saveConvs(na);
        } catch (Exception ignored) {}
    }

    private void showConvs() {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_convs, null);
        dialog.setContentView(v);

        ChipGroup cats = v.findViewById(R.id.convCats);
        String[] catIds = {"all", "default", "survival", "creative", "redstone", "build", "battle", "other"};
        for (String c : catIds) {
            Chip chip = new Chip(this);
            chip.setText(c.equals("all") ? R.string.conv_all : ConvAdapter.catRes(c));
            chip.setCheckable(true);
            chip.setTag(c);
            if (c.equals("all")) chip.setChecked(true);
            chip.setOnClickListener(x -> {
                for (int i = 0; i < cats.getChildCount(); i++) {
                    Chip ch = (Chip) cats.getChildAt(i);
                    ch.setChecked(ch == chip);
                }
                fillConvs(dialog, (String) chip.getTag());
            });
            cats.addView(chip);
        }

        v.findViewById(R.id.convNew).setOnClickListener(x -> { dialog.dismiss(); newConvDialog(); });
        fillConvs(dialog, "all");
        dialog.show();
    }

    private void fillConvs(BottomSheetDialog dialog, String cat) {
        RecyclerView rv = dialog.findViewById(R.id.convList);
        if (rv == null) return;
        JSONArray convs = prefs.getConvs();
        List<JSONObject> items = new ArrayList<>();
        for (int i = 0; i < convs.length(); i++) {
            JSONObject o = convs.optJSONObject(i);
            if (o == null) continue;
            if (!"all".equals(cat) && !cat.equals(o.optString("cat", "default"))) continue;
            items.add(o);
        }
        ConvAdapter ad = new ConvAdapter(items, prefs, new ConvAdapter.Listener() {
            @Override
            public void onOpen(JSONObject conv) {
                current = conv;
                prefs.setCurrentConv(conv.optString("id"));
                toolbar.setTitle(conv.optString("title"));
                loadOrCreateCurrent();
                adapter.notifyDataSetChanged();
                scrollBottom();
                dialog.dismiss();
            }

            @Override
            public void onDelete(JSONObject conv) {
                new AlertDialog.Builder(AiActivity.this)
                        .setTitle(R.string.conv_delete_confirm)
                        .setPositiveButton(R.string.ok, (d, w) -> {
                            JSONArray na = new JSONArray();
                            String id = conv.optString("id");
                            for (int i = 0; i < prefs.getConvs().length(); i++) {
                                JSONObject o = prefs.getConvs().optJSONObject(i);
                                if (o == null || !id.equals(o.optString("id"))) na.put(o);
                            }
                            prefs.saveConvs(na);
                            if (prefs.getCurrentConv().equals(id)) {
                                prefs.setCurrentConv("");
                                current = null;
                                loadOrCreateCurrent();
                                adapter.notifyDataSetChanged();
                                toolbar.setTitle(current.optString("title"));
                            }
                            fillConvs(dialog, cat);
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
            }
        });
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(ad);
        TextView empty = dialog.findViewById(R.id.convEmpty);
        empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void newConvDialog() {
        FrameLayout wrap = new FrameLayout(this);
        int pad = dp(20);
        wrap.setPadding(pad, pad / 2, pad, 0);

        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        EditText title = new EditText(this);
        title.setHint(R.string.conv_new_title);
        ll.addView(title);

        TextView catLabel = new TextView(this);
        catLabel.setText(R.string.conv_cat);
        catLabel.setTextSize(13f);
        catLabel.setPadding(0, dp(12), 0, dp(4));
        ll.addView(catLabel);

        ChipGroup cg = new ChipGroup(this);
        cg.setSingleSelection(true);
        String[] catIds = {"default", "survival", "creative", "redstone", "build", "battle", "other"};
        for (String c : catIds) {
            Chip chip = new Chip(this);
            chip.setText(ConvAdapter.catRes(c));
            chip.setCheckable(true);
            chip.setTag(c);
            if (c.equals("default")) chip.setChecked(true);
            cg.addView(chip);
        }
        ll.addView(cg);
        wrap.addView(ll);

        new AlertDialog.Builder(this)
                .setTitle(R.string.conv_new)
                .setView(wrap)
                .setPositiveButton(R.string.ok, (d, w) -> {
                    String cat = "default";
                    for (int i = 0; i < cg.getChildCount(); i++) {
                        Chip chip = (Chip) cg.getChildAt(i);
                        if (chip.isChecked()) cat = (String) chip.getTag();
                    }
                    JSONObject o = newConv(title.getText() == null ? "" : title.getText().toString().trim(), cat);
                    prefs.pushConv(o);
                    prefs.setCurrentConv(o.optString("id"));
                    current = o;
                    toolbar.setTitle(o.optString("title"));
                    loadOrCreateCurrent();
                    adapter.notifyDataSetChanged();
                    scrollBottom();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void send() {
        String text = input.getText() == null ? "" : input.getText().toString().trim();
        if (text.isEmpty() || sending) return;
        sending = true;
        send.setEnabled(false);
        msgs.add(new AiAdapter.Msg(true, text));
        input.setText("");
        adapter.notifyItemInserted(msgs.size() - 1);
        scrollBottom();
        saveCurrent();

        JSONObject st = prefs.getSettings();
        String base = AiClient.resolveBase(st, DataStore.get().providers);
        if (base.isEmpty()) {
            fail(getString(R.string.ai_no_base));
            return;
        }
        JSONArray messages = new JSONArray();
        try {
            JSONObject sys = new JSONObject();
            sys.put("role", "system");
            sys.put("content", st.optString("systemPrompt", DataStore.get().defaultPrompt));
            messages.put(sys);
            int start = Math.max(0, msgs.size() - 14);
            for (int i = start; i < msgs.size(); i++) {
                AiAdapter.Msg m = msgs.get(i);
                JSONObject u = new JSONObject();
                u.put("role", m.isUser ? "user" : "assistant");
                u.put("content", m.text);
                messages.put(u);
            }
        } catch (Exception ignored) {}

        final String promptText = text;
        new Thread(() -> {
            try {
                String reply = AiClient.chat(base, st, messages);
                runOnUiThread(() -> {
                    msgs.add(new AiAdapter.Msg(false, reply));
                    adapter.notifyItemInserted(msgs.size() - 1);
                    scrollBottom();
                    finishSend();
                    saveCurrent();
                    if (promptText.startsWith(getString(R.string.ai_optimize_prefix))) {
                        for (String c : DataStore.get().extractCmds(reply)) prefs.saveCmd(c);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    msgs.add(new AiAdapter.Msg(false, getString(R.string.ai_error, e.getMessage())));
                    adapter.notifyItemInserted(msgs.size() - 1);
                    scrollBottom();
                    finishSend();
                    saveCurrent();
                });
            }
        }).start();
    }

    private void fail(String msg) {
        msgs.add(new AiAdapter.Msg(false, msg));
        adapter.notifyItemInserted(msgs.size() - 1);
        scrollBottom();
        finishSend();
        saveCurrent();
    }

    private void finishSend() {
        sending = false;
        send.setEnabled(true);
    }

    private void scrollBottom() {
        RecyclerView rv = findViewById(R.id.aiList);
        rv.post(() -> rv.scrollToPosition(msgs.size() - 1));
    }

    private void showBook() {
        JSONArray saved = prefs.getAiSaved();
        List<String> cmds = new ArrayList<>();
        for (int i = 0; i < saved.length(); i++) cmds.add(saved.optJSONObject(i).optString("cmd"));
        String[] arr = cmds.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.ai_book_title, arr.length))
                .setItems(arr, (d, w) -> Clip.copy(this, arr[w]))
                .setPositiveButton(R.string.close, null)
                .show();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
