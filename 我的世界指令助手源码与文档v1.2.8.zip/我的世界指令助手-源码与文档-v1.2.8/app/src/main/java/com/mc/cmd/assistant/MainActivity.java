package com.mc.cmd.assistant;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.mc.cmd.assistant.data.Prefs;
import com.mc.cmd.assistant.ui.BuilderFragment;
import com.mc.cmd.assistant.ui.HomeFragment;
import com.mc.cmd.assistant.ui.IdsFragment;
import com.mc.cmd.assistant.ui.MyFragment;
import com.mc.cmd.assistant.ui.PresetFragment;
import com.mc.cmd.assistant.ui.VersionDialog;

public class MainActivity extends BaseActivity {

    private final Fragment[] pages = new Fragment[5];
    private int current = 0;
    private boolean onboarding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView nav = findViewById(R.id.nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            int idx = id == R.id.nav_builder ? 1 : id == R.id.nav_preset ? 2 : id == R.id.nav_ids ? 3 : id == R.id.nav_my ? 4 : 0;
            show(idx);
            return true;
        });
        if (savedInstanceState == null) show(0);

        applyTabExtra(getIntent());

        Prefs prefs = new Prefs(this);
        if (!prefs.isOnboarded()) {
            onboarding = true;
            showPrivacyDialog();
        }
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        applyTabExtra(intent);
    }

    private void applyTabExtra(android.content.Intent intent) {
        if (intent == null) return;
        String tab = intent.getStringExtra("tab");
        if (tab == null) return;
        int idx = "builder".equals(tab) ? 1 : "preset".equals(tab) ? 2 : "ids".equals(tab) ? 3 : 0;
        findViewById(R.id.nav).post(() -> {
            com.google.android.material.bottomnavigation.BottomNavigationView nav = findViewById(R.id.nav);
            nav.setSelectedItemId(idx == 1 ? R.id.nav_builder : idx == 2 ? R.id.nav_preset : idx == 3 ? R.id.nav_ids : R.id.nav_home);
            show(idx);
        });
    }

    private void showPrivacyDialog() {
        ScrollView sv = new ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(R.string.onboard_privacy_msg);
        tv.setTextSize(13f);
        tv.setLineSpacing(4f, 1f);
        tv.setPadding(dp(24), dp(16), dp(24), dp(16));
        sv.addView(tv);

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(R.string.onboard_privacy_title)
                .setView(sv)
                .setCancelable(false)
                .setPositiveButton(R.string.onboard_agree, (dialog, which) -> {
                    Prefs prefs = new Prefs(MainActivity.this);
                    prefs.setOnboarded();
                    VersionDialog.show(MainActivity.this, prefs, null);
                })
                .setNegativeButton(R.string.onboard_exit, (dialog, which) -> finish())
                .create();
        d.setOnShowListener(dlg -> {
            d.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(0xFF6750A4);
            d.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(0xFF999999);
        });
        d.show();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void show(int idx) {
        if (idx == current && pages[current] != null && pages[current].isAdded()) return;
        if (pages[idx] == null) {
            switch (idx) {
                case 1: pages[1] = new BuilderFragment(); break;
                case 2: pages[2] = new PresetFragment(); break;
                case 3: pages[3] = new IdsFragment(); break;
                case 4: pages[4] = new MyFragment(); break;
                default: pages[0] = new HomeFragment();
            }
        }
        current = idx;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, pages[idx])
                .commit();
    }
}
